import logging
import warnings
from math import floor
from pathlib import Path
from typing import Union, List, Tuple

import numpy as np
import pandas as pd
import pims
import trackpy as tp
from matplotlib import pyplot as plt
from pandas import DataFrame
from sklearn.neighbors import NearestNeighbors

import brc_lib.lib_math
from brc_lib import lib_img_handling as li
# def getROIsSR(im):
from brc_lib.lib_df_handling import check_and_read_csv
from brc_lib.lib_img_handling import circle_mask


def get_nearest_roi(
        df_rois: pd.DataFrame,
        df_evts: pd.DataFrame,
        px_size: int = 110,
        dummy: bool = False,
):
    """
    Adds the distance to nearest ROI and its index to the df_evts dataframe
    :param px_size: size of pixel to calculate dist_nm column. Ignore if not using real distances.
    :param df_rois: pandas DataFrame of ROIs, output from tp.locate
    :param df_evts: pandas DataFrame of events, output from tp.batch
    :return: df_evts: same as df_evts with extra columns
    """
    X = df_rois[["y", "x"]].values
    y = df_evts[["y", "x"]].values
    nbrs = NearestNeighbors(n_neighbors=1, algorithm="ball_tree").fit(X)
    ## For each event
    distances, nearest_roi = nbrs.kneighbors(y)

    if dummy:
        df_evts["nbrs_dummy_roi"] = nearest_roi
        df_evts["dist_dummy"] = distances
        df_evts["dist_nm_dummy"] = distances * px_size
    else:
        df_evts["nbrs_roi"] = nearest_roi
        df_evts["dist"] = distances
        df_evts["dist_nm"] = distances * px_size

    return df_evts


def getROIs_SR(
        im: np.ndarray,
        thres_ecc: Union[None, float] = None,
        minmass: Union[None, float] = None,
        crop_spots: Union[bool, None] = None,
) -> pd.DataFrame:
    """
    Retrieves ROIs with subpx accuracy
    :param im: image as ndarray of dim (y,x,1)
    :param thres_ecc: threshold in the interval 0 to 1,
    :return:
    """
    if minmass is None:
        minmass = 0.1
    if crop_spots is None:
        crop_spots = False
    if im.shape[-1] != 1:
        raise TypeError(
            "Not the right dimensions: only arrays of shape (y,x,1) "
            "are supported, this is {}".format(im.shape)
        )
    if im.max() > 1:
        warnings.warn(
            "Intensity has not been rescaled to range (0,1). Rescaling",
            UserWarning,
        )
        im = li._rescale_intensity(im, p1=0, p2=99.9)

    df_roi = tp.locate(im, diameter=5, minmass=minmass)
    df_roi.reset_index(inplace=True)

    if thres_ecc is not None:
        df_roi = df_roi[df_roi["ecc"] < thres_ecc]

    if crop_spots is True:
        remove_spots(df_roi)

    return df_roi


def gen_max_frame(frames: pims.ImageSequenceND):
    frames.bundle_axes = "cyx"
    for frame in frames:
        yield frame.max(axis=0)


def gen_green_frame(frames: pims.ImageSequenceND):
    frames.bundle_axes = "cyx"
    for frame in frames:
        yield frame[1]


def remove_spots(
        df: DataFrame, min_x: int = 15, max_x: int = 270,
):
    _idx_drop_x_min = df[df["x"] < min_x].index
    _idx_drop_x_max = df[df["x"] > max_x].index

    df.drop(_idx_drop_x_max, inplace=True)
    df.drop(_idx_drop_x_min, inplace=True)


def get_events_SR(
        frames,
        trace_type: str = "max",
        minmass: int = 40,
        size_particle: int = 11,
        percentile=95,
        crop_spots: bool = False,
):
    """
    Uses the trackpy module to get events
    Finds trajectories of particles and links
    returns final df with particle assignments
    :param frames: frames from PIMS, use the read_tiff_stack_PIMS function
    :param minmass: minimum mass of the integrated gaussian function in trackpy
    :param size_particle: diameter of particle, check with tp.subpx_bias
    :return:
    """
    frames.bundle_axes = "cyx"
    if len(frames) > 100:
        tp.quiet()
    if trace_type == "max":
        df_e = tp.batch(
            gen_max_frame(frames),
            size_particle,
            engine="numba",
            minmass=minmass,
            percentile=percentile,
        )
    elif trace_type == "green":
        df_e = tp.batch(
            gen_green_frame(frames),
            size_particle,
            engine="numba",
            minmass=minmass,
            percentile=percentile,
        )
    else:
        raise NotImplementedError(f"{trace_type} invalid value for trace_type")

    if crop_spots is True:
        remove_spots(df_e)

    df_t = tp.link_df(
        df_e, search_range=5, memory=0
    )  # use 0 memory because particles are so large so as to not be lost
    return df_t


def plot_n_event_occurences(
        df_events: DataFrame,
        frames: pims.ImageSequenceND,
        out_p: Path,
        n_frames=100,
        first_frame=0,
        title_string: str = "",
):
    if out_p.suffix != ".pdf":
        raise TypeError("Not the right file type")

    frame_shape = frames[0].shape
    _, frame_y, frame_x = frame_shape
    frames.bundle_axes = "cyx"

    for i, (frame, d) in enumerate(df_events.groupby(by=["frame"])):
        if i < n_frames:
            fig, ax = plt.subplots(
                figsize=(8, 8),
                constrained_layout=True,
                # subplot_kw={'adjustable': 'box-forced'},
            )
            # # pic = li._rescale_intensity(frames[frame].reshape((frame_y,frame_x,-1)), p1=0, p2=99.9)
            # pic = pims.display.to_rgb(frames[frame])
            # pic = frames[frame].max(axis=0)
            pic = frames[frame][1]
            tp.annotate(d, pic, plot_style={"markeredgewidth": 0.5}, ax=ax)

            ax.set_title(
                "Frame {}: N={} {}".format(
                    i + first_frame, len(d), title_string
                )
            )

            fig.savefig(
                Path(
                    str(out_p).replace(
                        ".pdf", "_frame{}.pdf".format(i + first_frame)
                    )
                )
            )
            plt.close(fig)


# TODO: Make this function run with numba
def extract_event_intensities_SR(
        df_t,
        frames,
        inner_radius: int = 4,
        outer_radius: int = 6,
        gap_space: int = 2,
        channel_names: Union[List[str], None] = None,
):
    """
    :param df_t: DataFrame containing all events and positions
    :param frames: frame object from which we extract intensities
    :return:
    """

    if channel_names is None:
        channel_names = ["red", "green", "blue"]

    # print params
    print("Exctracting event intensities using these parameters:")
    print(
        f"inner : {inner_radius}\nouter : {outer_radius}\ngap   : {gap_space}"
    )

    # Define channel and bg names
    bg_names = [s + "_bg" for s in channel_names]

    frames.bundle_axes = "cyx"

    cc, yy, xx = frames[0].shape

    # decide what to keep
    cols_keep = [
        "x",
        "y",
        "size",
        "ecc",
        "mass",
        "frame",
        "particle",
        "nbrs_roi",
        "dist",
        "dist_nm",
    ]

    df_list = []

    ## Do so by defining a ROI for EACH particle

    for index, row in df_t.iterrows():
        # x_r and y_r must be type int,
        x_r = floor(row.x)
        y_r = floor(row.y)
        frame_r = int(row.frame)

        # Make a mask for tracing
        masks = circle_mask(
            inner_radius=inner_radius,
            outer_radius=outer_radius,
            gap_space=gap_space,
            yx=(y_r, x_r),
            indices=np.indices((yy, xx)),
        )

        df_dict = row[cols_keep].to_dict()

        frame = frames[frame_r]

        for ci in range(frame.shape[0]):
            split_image = frame[ci]

            (
                intensity_spot_roi,
                intensity_spot_bg,
            ) = li.extract_intensities_from_stack(
                split_image, *masks, raw=True,  # not bg corr
            )

            # Put the data into a DF
            df_dict[channel_names[ci]] = intensity_spot_roi
            df_dict[bg_names[ci]] = intensity_spot_bg

        df_temp = pd.DataFrame(df_dict, index=[index])

        # print(df_temp)

        df_list.append(df_temp)

        # if len(df_list > 100):
        #     df_temp = pd.concat(df_list)
        #     df_list = [df_temp]

    df_new = pd.concat(df_list)
    try:
        df_new["_event_ID"] = df_new.particle
        df_new.set_index(keys="particle", inplace=True)
    except AttributeError as e:
        warnings.warn(
            f"{e} raised, carrying on without assigning _event_ID", UserWarning
        )
    # TODO : use the same method as before to combine the intensities from each frame?

    return df_new


if __name__ == "__main__":
    logging.getLogger("trackpy.feature").setLevel(logging.WARNING)

    frame_range = None

    # comparing old ROI and new ROI finding
    root_dir = Path("/Users/mag/Documents/study/phd/barcodeAssay/data/")
    file_path = root_dir.joinpath(
        "20190804/active 2 non filtered/0h00m/tif/mask.tif"
    )
    im = li.read_tif_image(file_path, input_format="None")
    im = im.mean(axis=2).reshape(im.shape[0], im.shape[1], 1)

    im_plot = li._rescale_intensity(im, p1=0, p2=99.9)

    movie_dir = "/Users/mag/Documents/study/phd/barcodeAssay/data/20190804/active neuraminidase and fucosidase/0h00m/tif/movie/"

    out_dir = Path(
        str(Path(movie_dir).parent.parent).replace("data", "results")
    )

    out_path = out_dir.joinpath("outputSR.csv")

    print(out_path)

    df_r = tp.locate(im_plot, diameter=5, minmass=0.1)

    df_r.reset_index(inplace=True)

    frames = li.read_tiff_stack_PIMS(movie_dir, frame_range=frame_range)

    df_e = tp.batch(frames, 9, engine="numba", minmass=500)

    print(df_e.head())

    df_e = get_nearest_roi(df_r, df_e)

    df_e.to_csv(out_path)


def add_dummy_ROI_distances(
        p_events: Path, p_rois: Path,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    df_evts = check_and_read_csv(p_events)
    df_rois = check_and_read_csv(p_rois)

    xmax = df_rois.x.values.max()
    ymax = df_rois.y.values.max()

    dims = (ymax, xmax)

    spots = li.convert_SR_ROIs_to_old(df_rois)

    spots_dummy = li.get_dummy_ROIs(spots, dims=dims, SR=True)

    df_rois_dummy = li.convert_old_ROIs_to_SR(spots_dummy)

    _df_evts = get_nearest_roi(df_rois_dummy, df_evts, dummy=True)

    assert len(_df_evts) == len(df_evts)

    return df_rois_dummy, _df_evts


def SR_get_ROI_df(
        im_mask,
        use_mean: bool = False,
        use_max: bool = False,
        thres_ecc=None,
        minmass=50,
        crop_spots: bool = False,
) -> Tuple[DataFrame, np.ndarray]:
    print("ROI finding")
    if use_mean:
        ROI_im = im_mask.mean(axis=2)
    elif use_max:
        ROI_im = im_mask.max(axis=2)
    else:
        ROI_im = im_mask

    ROI_im = li._rescale_intensity(ROI_im, p1=0, p2=99.9).reshape(
        (ROI_im.shape[0], ROI_im.shape[1], 1)
    )
    df_rois = getROIs_SR(
        ROI_im, thres_ecc=thres_ecc, minmass=minmass, crop_spots=crop_spots
    )
    return df_rois, ROI_im


def plot_and_inspect_ROIs(
        ROI_im: np.ndarray, df_rois: DataFrame, po_img: Path, savefig: bool
):
    fig, axes = plt.subplots(
        figsize=(8, 8),
        constrained_layout=True,
        # subplot_kw={'adjustable': 'box-forced'},
    )
    axes = tp.annotate(
        df_rois,
        ROI_im.reshape((ROI_im.shape[0], ROI_im.shape[1])),
        plot_style={"markeredgewidth": 0.5},
        ax=axes,
    )
    if savefig:
        fig.savefig(po_img)
        plt.close(fig)
    else:
        plt.show(fig)
        if not brc_lib.lib_math.query_yes_no("Accept ROIs?"):
            plt.close(fig)
            print("Better luck next time!")
            exit()
        else:
            plt.close(fig)
