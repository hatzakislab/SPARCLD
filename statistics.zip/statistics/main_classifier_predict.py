from pathlib import Path

if __name__ == "__main__":
    root_dir = Path(
        "/Users/mag/Documents/study/phd/barcodeAssay/results/20190804"
    )

    input_dir = root_dir.joinpath("active 2 non filtered")

    output_dir = input_dir.joinpath("figs/")
    output_dir.mkdir(exist_ok=True)

    p_dfs = []

    for p_expname in input_dir.iterdir():
        if p_expname.is_dir():
            for fp in p_expname.iterdir():
                if str(fp).endswith("outputSR_events.csv"):
                    p_dfs.append(fp)

    p_dfs = sorted(p_dfs)

    num_exps = len(p_dfs)

    print((p_dfs))
