from pathlib import Path

import matplotlib.pyplot as plt

import brc_lib.lib_df_handling
from brc_lib.lib_plotting import plot_intensity_histograms

if __name__ == "__main__":
    f = Path(
        "/Users/mag/Documents/study/phd/barcodeAssay/data/20190325/csvs/A_20ms.csv"
    )

    df = brc_lib.lib_df_handling.correct_bg(
        brc_lib.lib_df_handling.read_old_csv(f)
    )
    fig, axes = plt.subplots(nrows=3, constrained_layout=True)
    fig2, axes2 = plt.subplots(nrows=3, constrained_layout=True)

    axes, _, _ = plot_intensity_histograms(
        df, axes, fit_lognorm=True, range_x=(0, 15000)
    )
    axes2 = plot_intensity_histograms(
        df, axes2, fit_lognorm=False, range_x=(0, 15000)
    )

    fig.suptitle("With Lognorm")
    fig2.suptitle("No   Lognorm")

    plt.show()
