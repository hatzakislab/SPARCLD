import pickle
import re
import string
import warnings
from pathlib import Path
from typing import Union, Tuple, List, AnyStr

import networkx as nx
import numpy as np
import pandas as pd
import shap
import xgboost as xgb
from pandas import DataFrame
from sklearn import metrics
from sklearn.base import ClassifierMixin, TransformerMixin
from sklearn.metrics import confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from xgboost import XGBClassifier
from xgboost.core import XGBoostError

from brc_lib import lib_df_handling as ld
from brc_lib.lib_df_handling import preprocess_X
from brc_lib.lib_plotting import (
    plot_and_save_confusion_matrix,
    plot_and_save_shap_summary,
    plot_tree_from_file,
    nice_string_output,
)

signature_dict = {
    "1:0:5": "Fuc",
    "0:0:1": "Neu",
    "0:1:1": "Gal",
}


def balanced_accuracy_score(y_true, y_pred, sample_weight=None, adjusted=False):
    """Compute the balanced accuracy

    The balanced accuracy in binary and multiclass classification problems to
    deal with imbalanced datasets. It is defined as the average of recall
    obtained on each class.

    The best value is 1 and the worst value is 0 when ``adjusted=False``.

    Read more in the :ref:`User Guide <balanced_accuracy_score>`.

    Parameters
    ----------
    y_true : 1d array-like
        Ground truth (correct) target values.

    y_pred : 1d array-like
        Estimated targets as returned by a classifier.

    sample_weight : array-like of shape = [n_samples], optional
        Sample weights.

    adjusted : bool, default=False
        When true, the result is adjusted for chance, so that random
        performance would score 0, and perfect performance scores 1.

    Returns
    -------
    balanced_accuracy : float

    See also
    --------
    recall_score, roc_auc_score

    Notes
    -----
    Some literature promotes alternative definitions of balanced accuracy. Our
    definition is equivalent to :func:`accuracy_score` with class-balanced
    sample weights, and shares desirable properties with the binary case.
    See the :ref:`User Guide <balanced_accuracy_score>`.

    References
    ----------
    .. [1] Brodersen, K.H.; Ong, C.S.; Stephan, K.E.; Buhmann, J.M. (2010).
           The balanced accuracy and its posterior distribution.
           Proceedings of the 20th International Conference on Pattern
           Recognition, 3121-24.
    .. [2] John. D. Kelleher, Brian Mac Namee, Aoife D'Arcy, (2015).
           `Fundamentals of Machine Learning for Predictive Data Analytics:
           Algorithms, Worked Examples, and Case Studies
           <https://mitpress.mit.edu/books/fundamentals-machine-learning-predictive-data-analytics>`_.


    """
    C = confusion_matrix(y_true, y_pred, sample_weight=sample_weight)
    return balanced_accuracy_from_C(C, adjusted)


def balanced_accuracy_from_C(C, adjusted=False):
    with np.errstate(divide="ignore", invalid="ignore"):
        per_class = np.diag(C) / C.sum(axis=1)
    if np.any(np.isnan(per_class)):
        warnings.warn("y_pred contains classes not in y_true")
        per_class = per_class[~np.isnan(per_class)]
    score = np.mean(per_class)
    if adjusted:
        n_classes = len(per_class)
        chance = 1 / n_classes
        score -= chance
        score /= 1 - chance
    return score


def check_model(model: object) -> None:
    """
    checks whether the model is correct
    """
    clf, enc = model
    assert isinstance(clf, (xgb.XGBClassifier, ClassifierMixin))
    assert isinstance(enc, (TransformerMixin, LabelEncoder))
    pass


def reformat_label(label: str) -> str:
    # remove anything that isn't a number
    lab = label.translate(str.maketrans("", "", string.punctuation))
    lab = ":".join(lab)
    return lab


def get_csv_properties(p_csv: Path):
    names = ["date", "exptime", "label", "num"]
    values = p_csv.with_suffix("").name.split("_")

    # reformat the label here already
    try:
        check_label(values[2])
    except AssertionError:
        s = reformat_label(values[2])
        check_label(s)
        values[2] = s
    d = dict(zip(names, values))

    return d


def check_label(label: AnyStr) -> None:
    """
    checks if label is correct
    """
    assert bool(re.match(r"[0-9]:[0-9]:[0-9]", label))


def load_data_train(files: list, filtering=False, label_type="old"):
    """
    Loads training data from datafiles and splits the df into X and y
    :param label_type: old or new, depends on how the data looks. old uses old functionality
    :param files: list of files to use for loading training data
    :param filtering:
    :return: (X, y) X - pandas DF with labels removed, y - Pandas series of labels, name _LABEL
    """
    assert len(files) > 0
    df_list = []
    for i, fp in enumerate(files):
        if label_type == "old":
            label = str(fp.parent.name)
            if len(label) > 3:
                label = label[:3]
            label = ":".join(label)  # make format 1:1:1
        elif label_type == "new":
            d = get_csv_properties(fp)
            label = d["label"]
        else:
            raise ValueError(f"invalid value for label_type: {label_type}")

        df_temp = ld.check_and_read_csv(fp)
        cols_all, _ = ld.get_signal_columns(df_temp)

        df_temp["_LABEL"] = label

        df_list.append(df_temp)

    if len(df_list) == 1:
        df = df_list[0]
    else:
        df = pd.concat(df_list)

    if filtering is True:
        df = ld.filter_SNR(df, r=1.2)  # make sure to have

    X = df[cols_all]
    y = df["_LABEL"]

    return X, y


def add_column(df, column_name: str):
    print(f"Adding column: {column_name}")
    if column_name.startswith("ratio"):
        _, col_a, col_b = column_name.split("_")
        if f"ratio_{col_b}_{col_a}" in df.keys():
            col_values = 1.0 / df[f"ratio_{col_b}_{col_a}"]
        else:
            col_values = df[col_a] / df[col_b]
    elif column_name.endswith("log"):
        col, _ = column_name.split("_")
        col_values = np.log10(np.clip(df[col], 0.0001, max(df[col])))
    else:
        raise ValueError(f"The column name {column_name} is not compatible")
    return col_values


def add_missing_columns(X, clf) -> DataFrame:
    model_cols = clf.get_booster().feature_names
    missing_cols = [col for col in model_cols if col not in X.keys()]
    X = X.copy()
    if len(missing_cols) != 0:
        for col in missing_cols:
            X[col] = add_column(X, col)
    X = X[
        model_cols
    ]  # ensure the same order of columns. Will throw error with missing cols
    return X


def create_classifier(model_type="xgboost"):
    """
    Creates classifier clf
    :param model_type: string, defines which type of classifier to create
    :return clf: classifier
    """
    if model_type == "xgboost":
        clf = xgb.XGBClassifier()
    elif model_type == "xgboost_multi":
        clf = xgb.XGBClassifier(
            objective="multi:softprob", n_estimators=200, max_depth=5, n_jobs=4
        )
    else:
        raise NameError(
            "{} is not a valid type of classifier".format(model_type)
        )
    return clf


def create_encoder(encoder_type: str = "le") -> TransformerMixin:
    """
    Creates encoder.
    Currently only supports LabelEncoder
    :rtype: TransformerMixin
    """
    if encoder_type == "le":
        enc = LabelEncoder()
    else:
        raise NameError(
            "{} is not a valid type of encoder".format(encoder_type)
        )
    return enc


def get_new_model(
        model_type="xgboost", encoder_type="le",
) -> Tuple[Union[xgb.XGBClassifier, ClassifierMixin], TransformerMixin]:
    """
    Creates a new model, and returns it as a tuple
    a model in this case is composed of a classifier clf, and an encoder enc, in a tuple
    :param model_type: string, defines which model to use, passed on to create_classifier
    :param encoder_type:
    :return:
    """
    clf = create_classifier(model_type=model_type)
    enc = create_encoder(encoder_type=encoder_type)

    return (clf, enc)


def load_model(
        model_path: Union[Path, str],
) -> Tuple[Union[xgb.XGBClassifier, ClassifierMixin], TransformerMixin]:
    """
    Loads model from path, and checks it before passing it on
    :param model_path: Path object from which to load the model. must end with '.model'
    :return:
    """
    assert isinstance(model_path, (Path, str))
    if type(model_path) == str:
        model_path = Path(model_path)
    # ensure that the model path is the right extension
    assert str(model_path).endswith(".model")
    assert model_path.exists()
    model = pickle.load(open(str(model_path), "rb"))
    check_model(model)
    return model


def save_model(
        model: Tuple[Union[xgb.XGBClassifier, ClassifierMixin], TransformerMixin],
        path: Path,
) -> None:
    """
    Save model to path
    :param model: model object as defined above
    :param path: Path object to which the model will be saved
    """
    # First we ensure that the model path is the right extension
    assert str(path).endswith(".model")
    check_model(model)
    path.parent.mkdir(exist_ok=True)
    pickle.dump(model, open(str(path), "wb"))
    pass


def get_model(
        model_type: str = "xgboost_multi",
        encoder_type: str = "le",
        new_model: bool = False,
        model_name: Union[str, Path] = "",
) -> Tuple[Union[xgb.XGBClassifier, ClassifierMixin], TransformerMixin]:
    """
    If new_model is False, checks if a model is located at path
    else

    :param model_type: type of model
    :param encoder_type: type of encoder
    :param new_model: whether to create a new model
    :param model_name: if new_model is False, where to find the model to load
    :return model :
    """
    if new_model is False:
        try:
            model = load_model(model_name)
        except (
                TypeError,
                FileNotFoundError,
                AssertionError,
                IsADirectoryError,
        ) as e:
            print(f"load_model raised an {e}, creating new model")
            model = get_new_model(
                model_type=model_type, encoder_type=encoder_type
            )
    else:
        model = get_new_model(model_type=model_type, encoder_type=encoder_type)

    return model


def train_classifier(
        train_files: List[Path],
        model_path: Path,
        model_type: str = "xgboost",
        preprocess_log: bool = True,
        preprocess_ratios: bool = True,
        plot_confusionmatrix: bool = True,
        plot_shap_values: bool = True,
        label_type: str = "old",
        return_model: bool = False,
) -> Union[
    None,
    Tuple[
        Tuple[Union[xgb.XGBClassifier, ClassifierMixin], TransformerMixin],
        float,
    ],
]:
    fig_dir = model_path.parent.joinpath(f"figs_{model_path.stem}")

    X_df, y_label = load_data_train(
        train_files, filtering=False, label_type=label_type,
    )
    print(
        f"Loaded data: {len(train_files)} files with {len(y_label)} data points of {len(np.unique(y_label))} types."
    )

    X = preprocess_X(X_df, log=preprocess_log, ratios=preprocess_ratios, )

    model = get_model(new_model=True, model_type=model_type)
    (clf, enc) = model

    enc.fit(y_label)

    y = enc.transform(y_label)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

    clf.fit(X_train, y_train)

    y_pred = clf.predict(X_test)

    cm = metrics.confusion_matrix(y_test, y_pred)
    print("Confusion matrix: ")
    print(cm)

    print("Balanced Accuracy: ")
    bal_acc = balanced_accuracy_score(y_test, y_pred)
    print(balanced_accuracy_score(y_test, y_pred))

    if plot_confusionmatrix:
        fig_dir.mkdir(exist_ok=True)

        path_confmat = fig_dir.joinpath(
            model_path.stem + "_confusionmatrix.png"
        )

        title_string = f"Balanced Acc: {bal_acc:.4f}"
        plot_and_save_confusion_matrix(
            y_test, y_pred, path_confmat, np.unique(y_label), title_string
        )

    if plot_shap_values:
        fig_dir.mkdir(exist_ok=True)

        explainer = shap.TreeExplainer(clf)
        shap_values = explainer.shap_values(X)

        shap_path = fig_dir.joinpath(model_path.stem + "_summary_plot.png")
        plot_and_save_shap_summary(
            shap_values, X, shap_path,
        )

    model: Tuple[Union[XGBClassifier, ClassifierMixin], TransformerMixin] = (
        clf,
        enc,
    )
    check_model(model)

    if return_model:
        return model, bal_acc
    else:
        print(f"Saving model to {model_path}")
        save_model(model, model_path)
        pass


def predict_signatures(model, X_df):
    (clf, enc) = model

    y_pred = clf.predict(X_df)
    y_labels = enc.inverse_transform(y_pred)

    return y_labels


def _load_and_predict_signatures(model_path, X_df):
    model = load_model(model_path=model_path)

    y_labels = predict_signatures(model, X_df)

    return y_labels


def get_X_from_df(
        df: DataFrame, clf: Union[xgb.XGBClassifier, ClassifierMixin]
) -> DataFrame:
    cols_all, _ = ld.get_signal_columns(df)

    X = df[cols_all]

    X = preprocess_X(X)

    X = add_missing_columns(X, clf)

    return X


## BACKWARD SELECTION
def make_node_dictionary(
        model: Union[
            None, Tuple[Union[xgb.XGBClassifier, ClassifierMixin], TransformerMixin]
        ],
        score: float,
        name: Union[str, None] = None,
):
    parent_name = None
    if model is not None:
        clf, enc = model
        _classes = enc.classes_
    else:
        _classes = ""

    if type(name) == str:
        if "-" in name:
            parent_name = name.rsplit("-", maxsplit=1)[0]
    else:
        name = "_".join(sorted(_classes))

    node_dict = {
        "name": name,
        "classes": _classes,
        "model": model,
        "parent": parent_name,
        "score": score,
        "color": "xkcd:gunmetal",
    }
    return node_dict


def get_and_train_model(
        X, y_label, test_size: float = 0.25, return_confmat: bool = False
):
    n_labels = len(np.unique(y_label))
    if n_labels > 2:
        model_type = "xgboost_multi"
    else:
        model_type = "xgboost"

    model = get_model(new_model=True, model_type=model_type)
    (clf, enc) = model

    enc.fit(y_label)
    y = enc.transform(y_label)

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size
    )

    clf.fit(X_train, y_train)

    y_pred = clf.predict(X_test)
    bal_acc = balanced_accuracy_score(y_test, y_pred)

    if return_confmat:
        C = confusion_matrix(y_test, y_pred)
        return model, bal_acc, C
    else:
        return model, bal_acc


def _get_new_subset_model(classes_to_include):
    _subset_mask = y_label.isin(classes_to_include)

    _X = X[_subset_mask]
    _y_label = y_label[_subset_mask]

    return get_and_train_model(_X, _y_label)


def add_subnodes_fs(G, _node_name):
    _node = G.nodes[_node_name]

    _all_labels = np.unique(y_label)
    _parent_vals = _node["classes"].copy()
    _unused_labels: List = [l for l in _all_labels if l not in _parent_vals]

    if _unused_labels == []:
        raise ValueError("No more labels available")

    for val in _unused_labels:
        new_classes = list(_parent_vals.copy())
        new_classes.append(val)

        model, bal_acc = _get_new_subset_model(new_classes)

        _name_new = _node["name"] + f"-{val}"
        _dict_new = make_node_dictionary(model, bal_acc, name=_name_new)

        G.add_node(_name_new, **_dict_new)
        G.add_edge(_node_name, _name_new)


def add_subnodes_bs(G, _node_name):
    _node = G.nodes[_node_name]

    _parent_vals = _node["classes"].copy()

    for val in _parent_vals:
        _mask = _parent_vals != val
        new_classes = _parent_vals[_mask]

        model, bal_acc = _get_new_subset_model(new_classes)

        _name_new = _node["name"] + f"-{val}"
        _dict_new = make_node_dictionary(model, bal_acc, name=_name_new)

        G.add_node(_name_new, **_dict_new)
        G.add_edge(_node_name, _name_new)


def get_subnodes(G, _node_name):
    subnodes = list(nx.all_neighbors(G, _node_name))
    parent = G.nodes[_node_name]["parent"]
    if parent is not None:
        subnodes.remove(parent)
    return subnodes


def find_best_subnode_bs(
        G, base_node_name, key="score", maximize=True, last=False,
):
    _list_subnodes_sorted = sorted(
        get_subnodes(G, base_node_name),
        key=lambda l: G.nodes[l][key],
        reverse=maximize,
    )  # reverse is for the max

    name_maxnode = _list_subnodes_sorted[0]
    if last is False:
        add_subnodes_bs(G, name_maxnode)
    return name_maxnode


def find_best_subnode_fs(
        G, base_node_name, key="score", maximize=True, last=False,
):
    _list_subnodes_sorted = sorted(
        get_subnodes(G, base_node_name),
        key=lambda l: G.nodes[l][key],
        reverse=maximize,
    )  # reverse is for the max

    name_maxnode = _list_subnodes_sorted[0]
    if last is False:
        add_subnodes_fs(G, name_maxnode)
    return name_maxnode


def backward_selection(
        train_files: List[Path],
        out_path=Path,
        initial_node_name: Union[None, str] = "base",
        model_type: str = "xgboost",
        preprocess_log: bool = False,
        preprocess_ratios: bool = True,
        label_type: str = "new",
        TEST: bool = False,
        selection_rounds: int = 8,
):
    global X, X_df, y_label
    _initial_node_name = initial_node_name

    print("Running Backward Selection")
    X_df, y_label = load_data_train(
        train_files, filtering=False, label_type=label_type,
    )
    X = preprocess_X(X_df, log=preprocess_log, ratios=preprocess_ratios, )

    n_labels = len(np.unique(y_label))
    print("loaded and preprocessed data")
    print(f"data length: {len(y_label)}")
    print(f"num labels: {n_labels}")
    if TEST:
        _, X, _, y_label = train_test_split(X, y_label, test_size=0.05)
        n_labels = len(np.unique(y_label))
        print(f"data length: {len(y_label)}")
        print(f"num labels: {n_labels}")

    if selection_rounds > n_labels - 1:
        selection_rounds = n_labels - 1
        warnings.warn(
            f"Selection rounds will now be: {selection_rounds}", UserWarning
        )

    # Initialize Graph
    G = nx.Graph()

    # make a base model
    model, bal_acc = get_and_train_model(X, y_label)
    print("trained basic model")

    # Make the first node
    _initial_node_dict = make_node_dictionary(
        model, bal_acc, name=_initial_node_name
    )
    if _initial_node_dict["name"] != _initial_node_name:
        _initial_node_name = _initial_node_dict["name"]
    G.add_node(_initial_node_name, **_initial_node_dict)

    add_subnodes_bs(G, _initial_node_name)

    _ni = _initial_node_name

    # print(_ni)
    for i in range(selection_rounds):
        try:
            _ni = find_best_subnode_bs(G, _ni, maximize=True)
            # print(G.nodes[_ni])
            print_node(G.nodes[_ni])
            G.nodes[_ni]["color"] = "xkcd:rose red"
        except XGBoostError as e:
            print(f"Stopping at Iteration {i + 1} due to {e}")
        except ValueError as e:
            print(f"Stopping iteration due to ValueError:{e}")
            break

    _ni = find_best_subnode_bs(G, _ni, maximize=True, last=True)
    G.nodes[_ni]["color"] = "xkcd:rose red"
    G.nodes[_initial_node_name]["color"] = "xkcd:rose red"

    pickle.dump(G, open(str(out_path), "wb"))


def test_backward_selection():
    TEST = True
    data_dir = Path(
        "/Users/mag/Documents/study/phd/barcodeAssay/data/barcode_library/csv_output_still/"
    )
    out_dir = Path(
        "/Users/mag/Documents/study/phd/barcodeAssay/results/models/graphs"
    )
    out_dir.mkdir(exist_ok=True)
    out_path = out_dir.joinpath("test.pkl")
    train_files = [i for i in data_dir.glob("*.csv")]
    backward_selection(
        train_files,
        out_path=out_path,
        label_type="new",
        model_type="xgboost_multi",
        TEST=TEST,
    )
    f, a = plot_tree_from_file(out_path, save=False)


def forward_selection(
        train_files: List[Path],
        out_path=Path,
        initial_node_name: Union[None, str] = None,
        model_type: str = "xgboost",
        preprocess_log: bool = True,
        preprocess_ratios: bool = True,
        label_type: str = "new",
        TEST: bool = False,
        selection_rounds=8,
):
    global X, X_df, y_label
    _initial_node_name = initial_node_name

    print("Running Forward Selection")
    X_df, y_label = load_data_train(
        train_files, filtering=False, label_type=label_type,
    )
    X = preprocess_X(X_df, log=preprocess_log, ratios=preprocess_ratios, )

    n_labels = len(np.unique(y_label))
    print("loaded and preprocessed data")
    print(f"data length: {len(y_label)}")
    print(f"num labels: {n_labels}")
    if TEST:
        _, X, _, y_label = train_test_split(X, y_label, test_size=0.05)
        n_labels = len(np.unique(y_label))
        print(f"data length: {len(y_label)}")
        print(f"num labels: {n_labels}")

    if selection_rounds > n_labels - 1:
        selection_rounds = n_labels - 1
        warnings.warn(
            f"Selection rounds will now be: {selection_rounds}", UserWarning
        )

    # here create the first node

    if (type(_initial_node_name) == str) and (_initial_node_name in y_label):
        _initial_model = None
        _initial_score = 0.0
        _initial_node_dict = make_node_dictionary(
            _initial_model, _initial_score, _initial_node_name
        )
    else:
        _initial_node_dict = get_initial_forward_node_by_training(
            X, y_label, model_type, _name=_initial_node_name
        )

    if _initial_node_dict["name"] != _initial_node_name:
        _initial_node_name = _initial_node_dict["name"]

    # modify classes
    _initial_node_dict["score"] = 0.0
    _initial_node_dict["classes"] = np.array([_initial_node_name])

    # Initialize Graph
    G = nx.Graph()

    G.add_node(_initial_node_name, **_initial_node_dict)

    _ni = _initial_node_name
    add_subnodes_fs(G, _ni)

    for i in range(selection_rounds):
        try:
            _ni = find_best_subnode_fs(G, _ni, maximize=True)
            # print(G.nodes[_ni])
            print_node(G.nodes[_ni])
            G.nodes[_ni]["color"] = "xkcd:rose red"
        except ValueError as e:
            print(f"Stopping iteration due to ValueError:{e}")

    _ni = find_best_subnode_bs(G, _ni, maximize=True, last=True)

    G.nodes[_ni]["color"] = "xkcd:rose red"
    G.nodes[_initial_node_name]["color"] = "xkcd:rose red"

    pickle.dump(G, open(str(out_path), "wb"))

    pass


def print_node(node: dict):
    names = ["name", "parent", "score"]
    values = [node[name] for name in names]

    values = [val if type(val) == str else f"{val:.3f}" for val in values]

    print(nice_string_output(names, values))
    pass


def get_initial_forward_node_by_training(
        X, y_label, model_type="xgboost_multi", _name=None
):
    model, bal_acc, conf_mat = get_and_train_model(
        X, y_label, return_confmat=True
    )
    total_samples = conf_mat.sum(axis=1)[:, np.newaxis]
    normed_conf_mat = conf_mat.astype("float") / total_samples
    normed_diags = np.diag(normed_conf_mat)
    # max of diags will be index of the max label

    _max_ind = np.argmax(normed_diags)

    _max_y_label = sorted(np.unique(y_label))[_max_ind]

    _init_dict = make_node_dictionary(model, score=bal_acc, name=_max_y_label)

    return _init_dict


def test_forward_selection():
    TEST = False
    data_dir = Path(
        "/Users/mag/Documents/study/phd/barcodeAssay/data/barcode_library/csv_output_still/"
    )
    out_dir = Path(
        "/Users/mag/Documents/study/phd/barcodeAssay/results/models/graphs"
    )
    out_dir.mkdir(exist_ok=True)
    out_path = out_dir.joinpath("alldata_fs.pkl")
    fig_path = out_path.with_suffix(".pdf")

    # train_files = [i for i in data_dir.glob('*.csv')]
    # forward_selection(train_files, out_path=out_path, label_type='new', model_type='xgboost_multi', TEST=TEST)

    f, a = plot_tree_from_file(out_path, save=False)
    f.savefig(fig_path)
    return f, a
