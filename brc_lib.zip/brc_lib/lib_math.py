import sys
from typing import Iterable, Tuple, Union

import numpy as np
from scipy import optimize
from scipy.signal import savgol_filter
from sklearn.metrics import f1_score, balanced_accuracy_score, hamming_loss
from uncertainties import ufloat

np.random.seed(240597)


def is_in_any_element(check_str: str, itr: Iterable) -> bool:
    for i in itr:
        if check_str in i:
            return True
    return False


def get_euclidian_distance(pt1, pt2):
    a = np.array(pt1) - np.array(pt2)
    return np.sqrt(np.sum(a ** 2))


def get_all_distances(spots, testpt) -> np.ndarray:
    dists = np.zeros(shape=len(spots))
    for i in range(len(dists)):
        pt = spots[i]
        dists[i] = get_euclidian_distance(pt[:2], testpt[:2])

    return dists


def get_cumulative_event_arrs(arr: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    arr = arr.astype(int)
    x = np.arange(max(arr) + 1)
    y = np.zeros_like(x)

    for i in arr:
        y[i] += 1
    y = np.cumsum(y)

    x = x[min(arr):]
    y = y[min(arr):]

    return x, y


def filt_sg(x, wl=5):
    return savgol_filter(x, window_length=wl, polyorder=5)


def _func_exp_comp(_x: np.ndarray, _lambda, _N):
    return _N * np.exp(-1 * _lambda * _x)


def _func_double_exp(
        _x: np.ndarray, _lambda_1: float, _lambda_2: float, _k: float
):
    if _k > 1.0:
        raise ValueError
    if _k < 0:
        raise ValueError
    _exp1 = _lambda_1 * np.exp(-1 * _lambda_1 * _x)
    _exp2 = _lambda_2 * np.exp(-1 * _lambda_2 * _x)

    return _k * _exp1 + (1 - _k) * _exp2


def _func_exp(
        _x: np.ndarray, _lambda,
):
    return _lambda * np.exp(-_lambda * _x)


def fit_exponential(
        _x: np.ndarray,
        _y: np.ndarray,
        expectation_lifetime: Union[float, None] = None,
):
    """
    Fits an exponential to an array of numbers
    """

    if expectation_lifetime is None:
        expectation_lifetime = sum(_x * _y)
    _expectation_lam = 1.0 / expectation_lifetime

    _popt, _pcov = optimize.curve_fit(_func_exp, _x, _y, p0=_expectation_lam)

    _lam_unc = ufloat(_popt[0], _pcov[0] ** 2)

    return 1.0 / _lam_unc


def fit_exponential_composite(
        _x: np.ndarray, _y: np.ndarray, exp_lifetime: Union[float, None] = None
):
    """
    Fits an exponential to an array of numbers
    """

    if exp_lifetime is None:
        exp_lifetime = sum(_x * _y)
    _expectation_lam = 1.0 / exp_lifetime

    _popt, _pcov = optimize.curve_fit(
        _func_exp_comp, _x, _y, p0=(_expectation_lam, 1.0)
    )

    _lam_unc = ufloat(_popt[0], _pcov[0, 0] ** 2)

    _N_unc = ufloat(_popt[1], _pcov[1, 1] ** 2)

    return _N_unc, 1.0 / _lam_unc


def fit_double_exponential(_x: np.ndarray, _y: np.ndarray):
    _expectation_value = sum(_x * _y)
    _p0 = [_expectation_value, _expectation_value + 0.01, 0.4]
    _bounds = ((-np.inf, -np.inf, 0.001), (np.inf, np.inf, 0.999))

    _popt, _pcov = optimize.curve_fit(
        _func_double_exp, _x, _y, p0=_p0, bounds=_bounds
    )

    _lambda_1, _lambda_2, _k = _popt
    _lambda_1_u, _lambda_2_u, _k_u = np.diag(_pcov) ** 2

    _lambda_1_unc = ufloat(_lambda_1, _lambda_1_u)
    _lambda_2_unc = ufloat(_lambda_2, _lambda_2_u)
    _k_unc = ufloat(_k, _k_u)

    return _lambda_1_unc, _lambda_2_unc, _k_unc


def bin_data(
        x, n_bins=100, range_x=None, log=False, density=True, normalize=False,
):
    """
    Construct a normalized histogram of binned data with poisson uncertainties.

    :param x: ndarray
    :type x: np.array
    :param n_bins: number of bins
    :type n_bins: int
    :param range_x:
    :type range_x: tuple or None
    :param log: whether to use logarightmic bins
    :param density: whether the plot should be normalized
    :type density : bool
    :param normalize: bool, whether or not the histogram should be normalized

    :return: Histogram locations, values, uncertainties, mask
    """
    if range_x is None:
        range_x = (x.min(), x.max())

    if log:
        bins = np.logspace(np.log10(1), np.log10(range_x[1]), num=n_bins + 1)
    else:
        bins = np.linspace(*range_x, num=n_bins + 1)

    _counts, _bin_edges = np.histogram(x, bins=bins, density=False)
    _errors = np.sqrt(_counts)
    if density is True:
        _max_counts = _counts.max()
        _counts, _bin_edges = np.histogram(x, bins=bins, density=True)
        _errors = _errors * (_counts.max() / _max_counts)
    if normalize is True:
        _total_counts = _counts.sum()
        _counts /= _total_counts
        _errors /= _total_counts

    _bin_centers = 0.5 * (_bin_edges[1:] + _bin_edges[:-1])
    _mask = _counts > 0
    return _bin_centers, _counts, _errors, _mask


def find_optimum_threshold_separation(
        arr1: np.ndarray,
        arr2: np.ndarray,
        n_thres: int = 100,
        metric: str = "f1",
        return_thresholds: bool = False,
) -> Tuple[float, float, bool]:
    """
    Find the optimum threshold for differentiating two arrays based on the metric defined
    :param arr1: first set of samples
    :param arr2: second set of samples
    :param n_thres: number of thresholds to test
    :param metric: str, can be 'f1','acc',or 'hamming' defaults to 'f1', fastest
    :param return_thresholds: whether to also return thresholds


    :return threshold: optimum threshold
    :return f1_score: f1 score associated with threshold
    :return right_handed: Whether the threshold is right-handed (all above threshold is True) or left-handed (False)
    """
    if metric == "f1":
        met = f1_score
    elif metric.startswith("acc"):
        met = balanced_accuracy_score
    elif metric.startswith("hamming"):

        def met(y_true, y_pred):
            return 1.0 - hamming_loss(y_true, y_pred)

    else:
        raise NotImplementedError

    # ensure that we always have at least one sample with each label
    _min = min(arr1.min(), arr2.min()) + 0.0001
    _max = min(arr1.max(), arr2.max()) - 0.0001

    labels_1 = np.zeros_like(arr1)
    labels_2 = np.ones_like(arr2)

    arr_u = np.concatenate((arr1, arr2))
    labels_true = np.concatenate((labels_1, labels_2))
    thresholds: np.ndarray
    thresholds = np.linspace(_min, _max, num=n_thres)

    scores_r = np.zeros_like(thresholds)
    scores_l = np.zeros_like(thresholds)

    for i, thres_i in enumerate(thresholds):
        # test both right and left handed
        _labels_right = arr_u >= thres_i
        _labels_left = np.invert(_labels_right)

        _score_r = met(labels_true, _labels_right)
        _score_l = met(labels_true, _labels_left)

        scores_r[i] = _score_r
        scores_l[i] = _score_l

    if return_thresholds:
        return thresholds, scores_r, scores_l

    # get best value of both right and left
    f1_maxarg_right = np.argmax(scores_r)
    f1_maxarg_left = np.argmax(scores_l)

    f1_max_right = scores_r[f1_maxarg_right]
    f1_max_left = scores_l[f1_maxarg_left]

    if f1_max_right >= f1_max_left:
        return thresholds[f1_maxarg_right], f1_max_right, True
    else:
        return thresholds[f1_maxarg_left], f1_max_left, False


def query_yes_no(question, default="yes"):
    """Ask a yes/no question via raw_input() and return their answer.

    "question" is a string that is presented to the user.
    "default" is the presumed answer if the user just hits <Enter>.
        It must be "yes" (the default), "no" or None (meaning
        an answer is required of the user).

    The "answer" return value is True for "yes" or False for "no".
    """
    valid = {"yes": True, "y": True, "ye": True, "no": False, "n": False}
    if default is None:
        prompt = " [y/n] "
    elif default == "yes":
        prompt = " [Y/n] "
    elif default == "no":
        prompt = " [y/N] "
    else:
        raise ValueError("invalid default answer: '%s'" % default)

    while True:
        sys.stdout.write(question + prompt)
        choice = input().lower()
        if default is not None and choice == "":
            return valid[default]
        elif choice in valid:
            return valid[choice]
        else:
            sys.stdout.write(
                "Please respond with 'yes' or 'no' " "(or 'y' or 'n').\n"
            )
