from glob import glob
from pathlib import Path
from typing import Union, List, Tuple

import dask as da
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import pims
from dask.array import Array
from dask.array.image import imread as daimread
from matplotlib.colors import LinearSegmentedColormap
from numba import njit
from skimage.draw import circle, circle_perimeter
from skimage.exposure import rescale_intensity
from skimage.feature import blob_log
from skimage.io import imread as skimread

import brc_lib.lib_math as lm

np.random.seed(240597)


@njit
def px_nm(px, px_dim=160):
    """
    Gets the real size from a pixel size
    :return:
    """
    return px * px_dim


@njit
def sigma_to_r(sigma):
    """
    Returns radius in pixel size from given sigma
    :param sigma:
    :return:
    """
    return sigma * np.sqrt(2)


@njit
def sigma_to_nm(sigma):
    """
    Returns radius in nm from sigma,
    wraps sigma_to_r and px_nm
    :param sigma:
    :return:
    """
    return px_nm(sigma_to_r(sigma))


@njit
def nm_to_sigma(r_nm):
    """
    Returns corresponding sigma from nanometers
    :param r_nm:
    :return:
    """
    px = r_nm / 160.0
    sigma = px / np.sqrt(2)

    return sigma


def extract_intensities_from_stack(array, roi_mask, bg_mask, raw=True):
    """
    Extracts intensities from TIFF stack, given ROI and BG masks.
    Intensities are calculated as medians of all pixel values within the ROIs.

    Parameters
    ----------
    array:
        Single-channel currentMovie array
    roi_mask:
        Numpy mask for center
    bg_mask:
        Numpy mask for background
    raw:
        Whether to return raw signal/background intensities.
        Otherwise will return signal-background and background as zeroes.

    Returns
    -------
    Center and background intensities
    """
    if len(array.shape) == 3:  # tiff-stack
        roi_pixel_sum_intensity = np.nansum(array[:, roi_mask], axis=1)
        roi_pixel_mean_intensity = np.nanmean(array[:, roi_mask], axis=1)
        per_pixel_bg_intensity = np.median(array[:, bg_mask], axis=1)
        roi_n_pixels = len(roi_mask[roi_mask == True])

        bg_pixel_sum_intensity = per_pixel_bg_intensity * roi_n_pixels

    elif len(array.shape) == 2:  # single-frame tiff
        roi_pixel_sum_intensity = np.sum(array[roi_mask])
        roi_pixel_mean_intensity = np.mean(array[roi_mask])
        per_pixel_bg_intensity = np.median(array[bg_mask])

        roi_n_pixels = len(roi_mask[roi_mask == True])
        bg_pixel_sum_intensity = per_pixel_bg_intensity * roi_n_pixels

    else:
        raise ValueError("Image format not recognized")

    if raw:
        return roi_pixel_mean_intensity, per_pixel_bg_intensity
    else:
        signal = roi_pixel_sum_intensity - bg_pixel_sum_intensity

        background = np.zeros(signal.size)
        return signal / roi_n_pixels, background


@njit
def circle_mask_numba(inner_radius, outer_radius, gap_space, yx, im_shape):
    """
    Calculates a circular pixel mask for extracting intensities with numba

    Parameters
    ----------
    inner_radius:
        Area of the inner ROI -
        <1 for a ROI of 1 px
    outer_radius:
        Area of ROI + background + space
    gap_space:
        Area of a circle
    yx:
        Coordinates in the format (y, x)
    indices:
        Image indices (obtained from np.indices(img.shape))

    Returns
    -------
    Center and background ring ROIs
    """

    indices = np.indices(im_shape)
    yy, xx = yx

    yi, xi = indices
    mask = (yy - yi) ** 2 + (xx - xi) ** 2
    center = mask <= inner_radius ** 2
    gap = mask <= inner_radius ** 2 + gap_space ** 2
    bg_filled = mask <= outer_radius ** 2
    bg_ring = np.logical_xor(
        bg_filled, gap
    )  # subtract inner circle_overlap from outer

    return center, bg_ring


# @njit
def circle_mask(
        inner_radius,
        outer_radius,
        gap_space,
        yx,
        indices: Tuple[np.ndarray, np.ndarray],
):
    """
    Calculates a circular pixel mask for extracting intensities

    Parameters
    ----------
    inner_radius:
        Area of the inner ROI -
        <1 for a ROI of 1 px
    outer_radius:
        Area of ROI + background + space
    gap_space:
        Area of a circle
    yx:
        Coordinates in the format (y, x)
    indices:
        Image indices (obtained from np.indices(img.shape))

    Returns
    -------
    Center and background ring ROIs
    """
    yy, xx = yx

    yi, xi = indices
    mask = (yy - yi) ** 2 + (xx - xi) ** 2
    center = mask <= inner_radius ** 2
    gap = mask <= inner_radius ** 2 + gap_space ** 2
    bg_filled = mask <= outer_radius ** 2
    bg_ring = np.logical_xor(
        bg_filled, gap
    )  # subtract inner circle_overlap from outer

    return center, bg_ring


def get_ROI_positions(
        im,
        sigma_min=0.8,
        sigma_max=1.8,
        num_sigma=100,
        threshold=0.002,
        percentile=None,
) -> np.ndarray:
    """
    Finds spots using the laplacian of the gaussian function
    :param im: input image
    :param sigma_min: minimum sigma value for gaussian function
    :param sigma_max: maximum sigma value for gaussian function
    :param num_sigma: The number of intermediate values of standard deviations
        to consider between min_sigma and max_sigma.
    :param threshold: The relative lower bound for scale space maxima
    :param percentile: The relative lower bound for scale space maxima, as a percentile
    :return spots: (n, 3) ndarray : where n is the number of spots, of (y,x,sigma)
    """
    spots = blob_log(
        im,
        min_sigma=sigma_min,
        max_sigma=sigma_max,
        num_sigma=num_sigma,
        overlap=0,
        log_scale=True,
        threshold=(np.percentile(im, threshold) - np.min(im))
        if percentile is not None
        else threshold,
        # exclude_border = 5,
    )
    # Make sure that the spot array only has xy and r values
    if spots.shape[-1] > 3:
        spots = np.array([spots[:, 0], spots[:, 1], spots[:, -1], ]).T
    return spots


def convert_SR_ROIs_to_old(df_roi: pd.DataFrame) -> np.ndarray:
    return df_roi[["y", "x", "size"]].values


def convert_old_ROIs_to_SR(spots: List) -> pd.DataFrame:
    return pd.DataFrame(spots, columns=["y", "x", "size"])


def filter_ROIs(spots, min_r=None, max_r=200):
    sigma_arr = spots[:, -1]
    r_arr = sigma_to_nm(sigma_arr)

    if min_r is not None:
        accepted = spots[(r_arr >= min_r) & (r_arr <= max_r)]
    else:
        accepted = spots[r_arr <= max_r]

    return accepted


def read_tif_image(im_path: Path, input_format="xBRG") -> np.ndarray:
    """
    returns an RGB np array, depending on input_format
    :param im_path: path to .tif file to read from
    :param input_format: the order of the different channels in the .tif file
    :return: image array, RGB-image MxNx3
    """
    im = skimread(im_path)
    # if len(im.shape) == 2:  # if 1d mask

    if len(input_format) == 1:  # single color image
        im = im.reshape(im.shape[0], im.shape[1], 1)
    elif (
            input_format == "None"
    ):  # if we want to get the input from skimread directly
        return im
    elif input_format != "RGB":
        im_temp = np.zeros((im.shape[0], im.shape[1], 3))

        im_temp[:, :, 0] = im[:, :, input_format.index("R")]
        im_temp[:, :, 1] = im[:, :, input_format.index("G")]
        im_temp[:, :, 2] = im[:, :, input_format.index("B")]

        im = im_temp

    return im


def read_tiff_stack_PIMS(
        input_dir: Union[str, Path],
        input_format="RGBx",
        frame_range: Union[None, tuple] = None,
):
    if type(input_dir) is not str:
        input_dir = str(input_dir)

    # one of the indices should be ignored, if we have 4 dimensions
    chl_ignore_idx = input_format.index("x")
    chl_ignore_str = "_c00000{}".format(int(chl_ignore_idx + 1))

    frames_lst = sorted(glob(input_dir + "/*.tif"))
    frames_lst = [
        str(path_im)
        for path_im in frames_lst
        if chl_ignore_str not in str(path_im)
    ]

    if frame_range is not None:
        frames_lst = frames_lst[frame_range[0] * 3: frame_range[1] * 3]

    frames = pims.ImageSequenceND(frames_lst, axes_identifiers="ct")
    frames.bundle_axes = "cyx"
    return frames


@pims.pipeline
def crop_lea(img):
    return img[:, 10:266]


def read_tiff_movie(mov_path: Path, input_format="xBRG") -> np.ndarray:
    """
    returns an RGB np array, depending on input_format
    :param mov_path: path to .tif file to read from
    :param input_format: the order of the different channels in the .tif file
    :return: image array, RGB-image TxMxNx3
    """
    mov = skimread(mov_path)
    print("Read {}".format(str(mov_path)))
    print("Shape: {}".format(str(mov.shape)))
    exit()
    mov_xx = mov.shape[-2]
    mov_yy = mov.shape[-1]
    if len(input_format) == 1:  # single color movie
        mov = mov.reshape((-1, mov_xx, mov_yy, 1))
    else:
        mov = mov.reshape((-1, mov_xx, mov_yy, 4), order="F")

        if input_format != "RGB":
            print("reshaping")
            mov_temp = np.zeros((mov.shape[0], mov.shape[1], mov.shape[2], 3))

            mov_temp[:, :, :, 0] = mov[:, :, :, input_format.index("R")]
            mov_temp[:, :, :, 1] = mov[:, :, :, input_format.index("G")]
            mov_temp[:, :, :, 2] = mov[:, :, :, input_format.index("B")]

            mov = mov_temp

    return mov


def _rescale_intensity(
        image, p1: Union[int, float] = 0, p2: Union[int, float] = 99.9
) -> np.ndarray:
    """
    rescales image for plotting in matplotlib
    :param image: image to rescale
    :param p1: lower percentile to clip
    :param p2: upper percentile to clip
    :return img_rescale: rescaled image to use in matplotlib colormap
    """

    p1, p2 = np.percentile(image, [p1, p2])
    img_rescale = rescale_intensity(image, in_range=(p1, p2))
    return img_rescale


def get_rgb_from_single_channel(chl: np.ndarray, color="red") -> np.ndarray:
    """
    Makes an RGB of a single channel image, given color
    :param chl: ndarray of image
    :param color: str of which color to use
    :return: rgb output from color mapping of the color to the image.
    """
    chl_n = chl / chl.max()
    chl_n = _rescale_intensity(chl_n, p1=10, p2=100)
    cmap = LinearSegmentedColormap.from_list("", ["black", color])
    chl_p = cmap(chl_n)

    return chl_p


def plotChannels(im: np.ndarray, axes: list, plotMerged=False) -> None:
    """
    plots an images channel onto specified axes
    :param im: multicolor image
    :param axes: list of axes to plot on
    :param plotMerged: whether to plot the merged (max on second axis) plot on the last axes
    """
    chl_names = ["red", "green", "blue", "white"]

    chl_a = np.zeros(shape=(im.shape[0], im.shape[1], 4))

    for i in range(im.shape[-1]):
        # for i in range(im.shape[-1]):
        chl_p = get_rgb_from_single_channel(im[:, :, i], chl_names[i])

        axes[i].imshow(chl_p)

        chl_a += chl_p

    # make sure chl_a has the right alpha values
    chl_a[:, :, 3] = 1.0
    if plotMerged == True:
        # chl = im.max(axis=2)
        # chl_p = get_rgb_from_single_channel(chl, 'white')
        # axes[-1].imshow(chl_p)
        axes[-1].imshow(chl_a)
        # axes[-1].imshow(im)
    pass


def plot_ROIs_overlaid(spots, ax, label_rois=False) -> None:
    """
    Plots ROIs overlaid onto the specified axis.
    :param spots: spots
    :param ax: matplotlib axes
    """
    for ns, spot in enumerate(spots):
        y, x, r = spot
        c = plt.Circle(
            (x, y),
            r * np.sqrt(2),
            color="white",
            linewidth=0.5,
            fill=False,
            alpha=0.7,
        )
        ax.add_patch(c)
        if label_rois:
            t = ax.text(
                x=x + 0.05,
                y=y - 0.05,
                s="{}".format(ns),
                color="white",
                fontsize="xx-small",
            )
    pass


def extract_signatures_from_image(
        im, spots, inner_radius=1, outer_radius=5, gap_space=4, channel_names=None,
) -> pd.DataFrame:
    """
    Reads the signatures from an image, given ROIs to trace
    :param im: input image
    :param spots: ROIs to use for tracing
    :param inner_radius: area of the ROI to be traced
    :param outer_radius: area of the outer (background ROI)
    :param gap_space: gap between the inner and outer rings (ROI and bgROI)
    :param channel_names: list of channel names to make pd.DataFrame of. SHOULD not be changed!
    :return: df of ROIs signatures
    """
    if channel_names is None:
        channel_names = ["red", "green", "blue"]

    bg_names = [s + "_bg" for s in channel_names]

    split_images = [im[:, :, i] for i in range(im.shape[-1])]

    dfList = []

    for spot_n, spot in enumerate(spots):
        y, x, sigma = spot

        masks = circle_mask(
            inner_radius=inner_radius,
            outer_radius=outer_radius,
            gap_space=gap_space,
            yx=(y, x),
            indices=np.indices(split_images[0].shape),
        )

        df_dict = {}
        for ic, split_image in enumerate(split_images):  # loop through channels
            (
                intensity_spot_roi,
                intensity_spot_bg,
            ) = extract_intensities_from_stack(split_image, *masks, raw=True, )

            # Put the data into a DF
            df_dict[channel_names[ic]] = intensity_spot_roi
            df_dict[bg_names[ic]] = intensity_spot_bg

        df_temp = pd.DataFrame(df_dict, index=[spot_n])

        df_temp["_ROI_ID"] = spot_n
        df_temp["_ROI_X"] = x
        df_temp["_ROI_Y"] = y
        df_temp["_ROI_sigma_x10"] = sigma * 10

        dfList.append(df_temp)

    df = pd.concat(dfList)
    df.set_index(keys="_ROI_ID", inplace=True)
    return df


def get_traces_from_movie(
        im,
        spots,
        inner_radius: int = 1,
        outer_radius: int = 3,
        gap_space: int = 2,
        channel_names: Union[List[str], None] = None,
) -> pd.DataFrame:
    """
    Traces signal from a movie, given ROIs.
    In order to analyze, run df_events = getEvents(df) and analyze like output of extract_signatures_from_image
    :param im: input movie
    :param spots: ROIs to use for tracing
    :param inner_radius: area of the ROI to be traced
    :param outer_radius: area of the outer (background ROI)
    :param gap_space: gap between the inner and outer rings (ROI and bgROI)
    :param channel_names: list of channel names to make pd.DataFrame of. SHOULD not be changed!
    :return: df of ROIs signatures
    """
    if channel_names is None:
        channel_names = ["red", "green", "blue"]
    # Define channel and bg names
    bg_names = [s + "_bg" for s in channel_names]
    split_movies = [im[:, :, :, i] for i in range(im.shape[-1])]
    df_list = []
    xx, yy = split_movies[0].shape[1:]

    # Extract ROI values for all channels
    for spot_n, spot in enumerate(spots):
        # Define location of spot
        y, x, sigma = spot

        # Make a mask for tracing
        masks = circle_mask(
            inner_radius=inner_radius,
            outer_radius=outer_radius,
            gap_space=gap_space,
            yx=(y, x),
            indices=np.indices((xx, yy)),
        )
        df_dict = {}
        # images split by channels
        for ic, ic_movie in enumerate(split_movies):
            (
                intensity_spot_roi,
                intensity_spot_bg,
            ) = extract_intensities_from_stack(ic_movie, *masks, raw=True, )

            # Put the data into a DF
            df_dict[channel_names[ic]] = intensity_spot_roi
            df_dict[bg_names[ic]] = intensity_spot_bg
        df_temp = pd.DataFrame.from_dict(df_dict)

        df_temp["_ROI_ID"] = spot_n
        df_temp["_ROI_X"] = x
        df_temp["_ROI_y"] = y
        df_temp["_ROI_sigma_x10"] = sigma * 10
        df_temp["_Time"] = df_temp.index
        df_list.append(df_temp)

    df = pd.concat(df_list)

    return df


def get_circle_coordinates(xc, yc, r, fill=False):
    """
    Input:
    (xc, yc)= tuple coordinates of center
    r       = int   radius of circle
    fill    = bool  whether circle should be filled

    Output:
    coors  = ndarrays of coordinates of circle

    """

    if fill:
        xx, yy = circle(xc, yc, r)
    else:
        xx, yy = circle_perimeter(xc, yc, r)

    coors = np.asarray((xx, yy)).transpose()
    return coors


def get_dummy_ROIs(
        spots_active,
        n_rois: Union[int, None] = None,
        dims: Union[int, tuple] = 256,
        dist=5,
        rois_r=2,
        SR: bool = False,
):
    """
    Randomly generates ROIs that are distributed across the image.
    ROIs will be a minimum distance from each other and from all active ROIs
    :param spots_active:
    :param n_rois:
    :param dims:
    :param dist:
    :param rois_r:
    :param SR:
    :return:
    """
    if type(dims) is int:
        dims = (dims, dims)

    spots_active = list(spots_active)

    if n_rois is None:
        n_rois = len(spots_active)

    spots_inactive = []

    print(dims)

    while len(spots_inactive) < n_rois:
        # pt_cand = np.random.random_integers(low=0, high=dims, size=2)
        if SR is False:
            pt_cand = (
                int(np.random.randint(low=0, high=dims[0])),
                int(np.random.randint(low=0, high=dims[1])),
            )
        else:
            pt_cand = (
                np.random.uniform(low=0, high=dims[0]),
                np.random.uniform(low=0, high=dims[1]),
            )

        dists = lm.get_all_distances(spots_active, pt_cand)

        pt_cand = np.array([pt_cand[0], pt_cand[1], rois_r])

        if np.any(dists < dist):  # reject
            pass
        else:  # candidate can be accepted, add to original array to make sure no dummy rois overlap
            spots_active.append(pt_cand)
            spots_inactive.append(pt_cand)

    return np.array(spots_inactive)


def read_tiff_movie_dask(folder: Path):
    mov: da.array.Array = daimread(str(folder) + "/*.tif", )
    dims_old = mov.shape

    mov_xx = mov.shape[-2]
    mov_yy = mov.shape[-1]

    mov = mov.reshape((-1, mov_xx, mov_yy, 1))

    mov_d0 = mov[0::4]
    mov_d1 = mov[1::4]
    mov_d2 = mov[2::4]

    mov_new = da.array.concatenate([mov_d0, mov_d1, mov_d2], axis=-1)

    return mov_new


def get_trace_from_movie_dask(
        mov: da.array.Array,
        spots: np.ndarray,
        inner_radius=1,
        outer_radius=5,
        gap_space=4,
        max_frames=5000,
        channel_names=None,
) -> pd.DataFrame:
    """
        Traces signal from a movie, given ROIs.
        In order to analyze, run df_events = getEvents(df) and analyze like output of extract_signatures_from_image
        :param mov: input movie
        :param spots: ROIs to use for tracing
        :param inner_radius: area of the ROI to be traced
        :param outer_radius: area of the outer (background ROI)
        :param gap_space: gap between the inner and outer rings (ROI and bgROI)
        :param channel_names: list of channel names to make pd.DataFrame of. SHOULD not be changed!
        :return: df of ROIs signatures
        """
    if channel_names is None:
        channel_names = ["red", "green", "blue"]
    # Define channel and bg names
    bg_names = [s + "_bg" for s in channel_names]

    # xx, yy = mov.shape[[1,2]]

    df_list = []

    movie_len = mov.shape[0]

    # ceiling division to find number of splits in movie
    n_splits = -(-movie_len // max_frames)

    movie_splits = [n * max_frames for n in range(n_splits)]

    for i, split in enumerate(movie_splits):
        movie_start = split
        movie_stop = split + max_frames
        if movie_stop > movie_len:
            movie_stop = movie_len
        print(
            "Now tracing from frame {} to frame {}".format(
                movie_start, movie_stop
            )
        )
        mov_temp = mov[movie_start:movie_stop]

        df_temp = get_traces_from_movie(
            mov_temp.compute(),
            spots=spots,
            inner_radius=inner_radius,
            outer_radius=outer_radius,
            gap_space=gap_space,
            channel_names=channel_names,
        )

        df_temp["_Time"] += movie_start

        df_list.append(df_temp)

    df_final = pd.concat(df_list)

    return df_final


if __name__ == "__main__":
    # file_path = lf.get_filename(initialDir=Path('/Users/mag/Documents/study/phd/barcodeAssay/data/'))
    root_dir = Path("/Users/mag/Documents/study/phd/barcodeAssay/data/")
    file_path = root_dir.joinpath(
        "20190804/active 2 non filtered/0h00m/tif/mask.tif"
    )
    im = read_tif_image(file_path, input_format="None")
    im = im.mean(axis=2).reshape(im.shape[0], im.shape[1], 1)

    im_plot = _rescale_intensity(im, p1=0, p2=99.9)

    spots = get_ROI_positions(
        im_plot, threshold=0.05, num_sigma=20, sigma_min=1, sigma_max=2
    )
    fig, axes = plt.subplots(
        figsize=(8, 8),
        # subplot_kw={'adjustable': 'box-forced'},
        constrained_layout=True,
    )

    plotChannels(
        im, [axes], plotMerged=False
    )  # wrap axes in a list for compatibility
