from pathlib import Path

from brc_lib.lib_classify import train_classifier

if __name__ == "__main__":
    root_dir = Path(
        "/Users/mag/Documents/study/phd/barcodeAssay/data/barcode_library/csv_output_still/"
    )
    model_dir = Path("/Users/mag/Documents/study/phd/fusionAssay/models")
    model_dir.mkdir(exist_ok=True)
    model_path = model_dir.joinpath("6_test.model")

    train_files = [i for i in root_dir.glob("*.csv")]

    # UNCOMMENT THIS SECTION TO USE A SUBSET
    substring_list = [
        "1.0.5",
        "1.1.1",
        "5.0.1",
        "0.0.1",
        "1.0.0",
        "0.1.0",
    ]

    train_files = [
        f
        for f in train_files
        if any(substring in str(f) for substring in substring_list)
    ]
    train_classifier(
        train_files,
        model_path,
        plot_confusionmatrix=True,
        label_type="new",
        model_type="xgboost_multi",
    )
