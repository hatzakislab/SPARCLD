import ast
from itertools import combinations
from pathlib import Path
from typing import Union

import numpy as np
import pandas as pd
from pandas import DataFrame
from scipy.signal import find_peaks, peak_widths

from brc_lib import lib_math as lm
from brc_lib.lib_file_handling import raw_cols


def is_private_column(name: str, prefix: str = "_") -> bool:
    """
    :param name: column name
    :param prefix: beginning prefix, defining a private column
    :return: bool
    """
    return name.startswith(prefix)


def get_signal_columns(df: pd.DataFrame) -> tuple:
    """
    removes private columns, and returns signal (rw + bg ) and raw column names.
    :param df:
    :return cols_all: signal column names
    :return cols_colors: raw (excluding bg) column names
    """
    # return cols, but remove "private" cols, those that shouldn't be read in the peakfinder
    cols = list(df.keys())
    cols_all = [col for col in cols if col in raw_cols]
    cols_colors = [col for col in cols_all if not col.endswith("_bg")]
    return cols_all, cols_colors


def subtract_bg(rw_tup: tuple):
    rw = rw_tup[0]
    bg = rw_tup[1]

    sig = np.abs(rw - bg)
    return sig


def do_bg_correction(df):
    _, colors = get_signal_columns(df)
    for col in colors:
        df[col] -= df[col + "_bg"]
    return df[colors].copy(deep=True)


def correct_bg(df):
    df = df.copy(deep=True)
    keys = df.keys()
    keys_c = [k for k in keys if k + "_bg" in keys]

    keys_keep = [k for k in keys if k not in raw_cols]

    df_new = df[keys_keep].copy(deep=True)

    for k in keys_c:
        df_new[k] = df[k] - df[k + "_bg"]
        df_new[k + "_bg"] = df[k + "_bg"]

    return df_new


def get_peaks_sigma_threshold(
        df: pd.DataFrame, color: str, n_sigma=7, use_background=False
):
    """

    :type df: pd.DataFrame
    :param df:
    :param color: string specified as a channel name
    :param n_sigma: number of sigma to set as a threshold for detecting peaks
    :param use_background: bool, whether to use background to calculate sigma threshold

    :return mask: 1d bool array
    :return mean: float
    :return std: float
    :return peak_frac: float, number of points that are in a peak within an array
    """
    col_bg = color + "_bg"
    if use_background:
        xarr = df[color].values
        mean = df[col_bg].mean()
        std = df[col_bg].std()
    else:
        xarr = (df[color] - df[col_bg]).values
        mean = xarr.mean()
        std = xarr.std()
    threshold = mean + n_sigma * std

    mask = xarr > threshold

    peak_frac = np.sum(mask) / len(mask)

    return mask, mean, std, peak_frac


def get_peaks_prominence(
        df: pd.DataFrame, color: str, threshold=250, rel_height=0.25
):
    x = df[color].values
    peaks, peak_properties = find_peaks(x, prominence=threshold)

    widths, width_heights, left_ips, right_ips = peak_widths(
        x, peaks=peaks, rel_height=rel_height
    )

    mask = np.zeros_like(x, dtype=bool)

    # run from each left ips to right ips and make mask there
    edges_l = np.array(left_ips.round(decimals=0), dtype=int)
    edges_r = np.array(right_ips.round(decimals=0), dtype=int)

    for l, r in zip(edges_l, edges_r):
        mask[l: r + 1] = True

    return mask


def makeEventIDs(df: pd.DataFrame, ROI_ID) -> list:
    """
    From a df with events labelled (using for example the getPeakSigmaThreshold) in event mask, enumerates unique events
    Use before grouping events
    :param df: pandas DataFrame with information of the event signal, mask and ROIs
    :param ROI_ID: ID of the ROI in the DF for which to set the event
    :return: event_ids, to be identified with the events in each ROI
    """
    df = df.copy()

    mask_diff = df["_event_mask"]

    # Now make a trace where each events gets a separate value

    event_counter = 0

    event_mask = np.zeros_like(mask_diff)

    for i, msk in enumerate(mask_diff):
        # Define an 'event' starting when diff == 1, and ending when it is -1
        if msk == 1:
            event_counter += 1
            event_mask[i] = event_counter
        elif msk == -1:
            event_mask[i] = 0
        elif msk == 0:
            event_mask[i] = event_mask[i - 1]

    event_ids = []

    for i, evt_num in enumerate(event_mask):
        if evt_num == 0:
            event_ids.append(None)
        else:
            evt_id = "{:04}_{:02}".format(ROI_ID, int(evt_num))
            event_ids.append(evt_id)

    return event_ids


def get_event_properties(
        df: pd.DataFrame, df_evt_id: str, exclude_outer: bool = True
) -> dict:
    """
    Adds a series of event classifiers from a grouped DataFrame
    :param exclude_outer: Excludes the first and last frame from calculation of samples if duration is more than 2
    :param df: grouped df
    :param df_evt_id: event id
    :return property_dict: dict of properties from the events to save and store
    """
    cols_sig, cols_raw = get_signal_columns(df)

    evt_duration = len(df)

    frame_start = df["_Time"].min()
    frame_end = df["_Time"].max()

    # make a dictionary of the values of each event
    if (exclude_outer is True) and (evt_duration > 2):
        # remove first and last frame from calculation of signals
        property_dict = df[1:-1][cols_sig].mean().to_dict()
    else:
        property_dict = df[cols_sig].mean().to_dict()

    property_dict["_event_duration"] = evt_duration
    property_dict["_event_start"] = frame_start
    property_dict["_event_end"] = frame_end

    # now get all the other rows (xyz etc) thrown in to keep the data the same place

    cols_to_remove = cols_sig + ["_event_mask"]

    cols_add = [col for col in list(df.keys()) if col not in cols_to_remove]

    if cols_add:  # ignoring if the list is empty
        cols_dict = df.reset_index().loc[0, cols_add].to_dict()
        property_dict = {
            **property_dict,
            **cols_dict,
        }

    return property_dict


def get_event_edges(df: pd.DataFrame, method="sigma", n_sigma=7) -> np.ndarray:
    """
    gets the edges of each event,
    :param df: df for a SINGLE ROI's raw data
    :return mask_diff: mask of [-1,0,1], to be used in makeEventIDs
    """
    cols_sig, cols_raw = get_signal_columns(df)

    masks = {}

    for col in cols_raw:
        if method == "sigma":
            mask, mean, std, peak_frac = get_peaks_sigma_threshold(
                df, color=col, n_sigma=n_sigma, use_background=False
            )

        elif method == "prominence":
            mask = get_peaks_prominence(df, color=col)
        else:
            raise ValueError(
                f"{method} is not a valid input for parameter method"
            )
        masks[col] = mask

    mask_combined = np.sum(list(masks.values()), axis=0)

    mask_diff = np.diff(
        np.array(np.array(mask_combined, dtype=bool), dtype=int)
    )

    # Add one zero at the beginning to correct index
    mask_diff = np.concatenate([np.zeros(shape=1), mask_diff])

    return mask_diff


def getEvents(
        df: pd.DataFrame,
        n_rois: Union[int, None] = None,
        method: str = "sigma",
        n_sigma: int = 7,
        exclude_outer: bool = False,
) -> pd.DataFrame:
    """
    Gets a new DataFrame of events, durationtimes, signatures, etc. from a large DF extracted from a TIF-file
    using get_traces_from_movie function
    :param df:
    :param n_rois: Number of ROIs to get events from, use for testing
    :return df_events: DataFrame with columns:
        '_ROI_ID', '_ROI_X', '_ROI_y', '_duration', '_event_ID', '_frame',
       'green', 'green_bg'
    """
    cols_sig, cols_raw = get_signal_columns(df)

    dfs_events = []

    # read peakfinder for each ROI
    n_events = 0

    for ROI_ID, df_roi in df.groupby(["_ROI_ID"]):
        df_roi["_event_mask"] = get_event_edges(
            df_roi, method=method, n_sigma=n_sigma
        )

        df_roi["_event_ID"] = makeEventIDs(df_roi, ROI_ID)

        for df_evt_id, df_evt in df_roi.groupby(["_event_ID"]):
            property_dict = get_event_properties(
                df_evt, df_evt_id, exclude_outer=exclude_outer
            )

            df_prop_temp = pd.DataFrame([property_dict])

            dfs_events.append(df_prop_temp)
        print(
            "ROI number: {} - {} evts".format(
                ROI_ID, len(dfs_events) - n_events
            )
        )
        n_events = len(dfs_events)
        if (n_rois is not None) and (ROI_ID > n_rois):
            break

    df_events = pd.concat(dfs_events, ignore_index=True)
    return df_events


def filter_SNR(_df, r=1.1) -> pd.DataFrame:
    """
    filters a DF by signal-to-noise ratio
    :param _df: dataframe with signals
    :param r: ratio to threshold by. Should be over 1 to make sense
    :return:
    """
    # _df = df.copy(deep=True)
    cols_sig, cols_raw = get_signal_columns(_df)

    cols_snr = ["_snr_" + col for col in cols_raw]

    for col in cols_raw:
        col_bg = col + "_bg"
        _df["_snr_" + col] = _df[col] / _df[col_bg]

    indexDrop = _df[
        (_df[cols_snr[0]] <= r)
        & (_df[cols_snr[1]] <= r)
        & (_df[cols_snr[2]] <= r)
        ].index

    return _df.drop(indexDrop)


def filter_duration(
        df: pd.DataFrame, min_frames: int = 1, max_frames: int = 20
):
    _df = df.copy(deep=True)

    index_drop = _df[
        (_df.duration < min_frames) | (_df.duration > max_frames)
        ].index
    return _df.drop(index_drop)


def filter_events_by_distance(
        df_evts: pd.DataFrame, distance: int = 4, dist_format: str = "px"
) -> pd.DataFrame:
    if dist_format == "nm":
        dist_col = "dist_nm"
    elif dist_format == "px":
        dist_col = "dist"
    elif dist_format == "px_dummy":
        dist_col = "dist_dummy"
    elif dist_format == "nm_dummy":
        dist_col = "dist_nm_dummy"
    else:
        raise ValueError(
            "dist_format can not take value {} ".format(dist_format)
        )

    index_drop = df_evts[
        df_evts[dist_col] > distance
        ].index  # use greater operator to just find indices to drop

    return df_evts.drop(index_drop)


def filter_events_by_rel_distance(df_evts: pd.DataFrame, ) -> pd.DataFrame:
    index_drop = df_evts[
        df_evts["dist"] > df_evts["size"]
        ].index  # use greater operator to just find indices to drop

    return df_evts.drop(index_drop)


## CSV Functions below


def csv_old_check(p: Path):
    # check if csv
    if p.suffix != ".csv":
        raise TypeError("Not the right file format!")
    testline = p.read_text().splitlines()[1]
    old_status = "(" in testline  # old csvs store values as tuples, which have

    return old_status


def read_csv_with_tuples(filename, ):
    """
    reads CSVS that need to be literally evaluated (when a column has a tuple in a col)
    :param filename:
    :return:
    """
    df = pd.read_csv(
        filename,
        converters={
            "0": ast.literal_eval,
            "1": ast.literal_eval,
            "2": ast.literal_eval,
            "blue": ast.literal_eval,
            "red": ast.literal_eval,
            "green": ast.literal_eval,
        },
    )
    return df


def read_old_csv(filename):
    col_dict = {"0": "blue", "1": "red", "2": "green"}
    df = read_csv_with_tuples(filename).rename(columns=col_dict)

    keys = df.keys()

    for k in keys:
        if k in list(col_dict.values()):
            df_temp = df[k].apply(pd.Series)
            signal_ = df_temp[0]
            bg_ = df_temp[1]

            df[k + "_bg"] = bg_
            df[k] = signal_

    return df


def check_and_read_csv(p) -> pd.DataFrame:
    if csv_old_check(p):
        df = read_old_csv(p)
    else:
        df = pd.read_csv(p)

    if "Unnamed: 0" in df.keys():
        df.drop(columns=["Unnamed: 0"], inplace=True)
    if "Unnamed: 0.1" in df.keys():
        df.drop(columns=["Unnamed: 0.1"], inplace=True)

    return df


def get_mean_sigma_values(df_trace: pd.DataFrame, corr_bg: bool = True) -> dict:
    cols_sig, cols_raw = get_signal_columns(df_trace)
    param_dict = {}

    for col_s in cols_raw:
        if corr_bg:
            xarr = df_trace[col_s].values - df_trace[col_s + "_bg"].values
        else:
            xarr = df_trace[col_s].values
        mean = xarr.mean()
        sigma = xarr.std()

        param_dict[col_s] = (mean, sigma)

    return param_dict


def add_particle_duration(df: pd.DataFrame) -> None:
    df.sort_values(["particle", "frame"], inplace=True)
    arr_lens = np.zeros_like(df["frame"])
    ind = 0
    for i, (g, d) in enumerate(df.groupby("particle")):
        l = len(d)
        new_ind = ind + l
        arr_lens[ind:new_ind] = l
        ind = new_ind
    df["duration"] = arr_lens
    pass


if __name__ == "__main__":

    fname = Path(
        "/Users/mag/PycharmProjects/improved-eureka/sample/oneColorLongMovie.csv"
    )

    # Function params
    excludeFirstFrame = False
    testing = True
    # Read DF
    df = pd.read_csv(fname)
    # df = genTraceData()

    if excludeFirstFrame == True:
        df = df[df._frame != 0]

    df_events = getEvents(df)
    print(df_events.keys())
    print(df_events)


def is_preprocessed(X) -> bool:
    """
    Quick check for whether X is preprocessed,
    checks if background correction has been done
    :param X:
    :return:
    """
    return lm.is_in_any_element("_bg", X.columns)


def preprocess_X(
        df: DataFrame, log: bool = True, ratios: bool = True,
) -> DataFrame:
    """
    Adds columns and more, depending on the boolean switches
    :param df:
    :param log:bool, whether to include log values of the different colors
    :param ratios:bool, whether to include ratios between the different colors
    :return df : preprocessed
    """
    # Start by bg correcting (if it has been done already, nothing should happen here)
    df = df.copy()
    df = do_bg_correction(df)
    _, colors = get_signal_columns(df)

    colors = sorted(colors, reverse=True)

    if log:
        for col in colors:
            logcol = f"{col}_log"
            df[logcol] = np.log10(np.clip(df[col], 0.0001, max(df[col])))
    if ratios:
        for col_a, col_b in combinations(colors, 2):
            df[f"ratio_{col_a}_{col_b}"] = df[col_a] / df[col_b]

    if df.isna().any().any():
        df.fillna(value=0, inplace=True)

    return df
