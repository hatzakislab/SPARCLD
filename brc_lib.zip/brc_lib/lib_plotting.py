import pickle
from pathlib import Path
from typing import Union, List, Tuple

import matplotlib
import numpy as np
import pandas as pd
import shap
from matplotlib import pyplot as plt
from uncertainties import nominal_value

plt.rcParams["font.family"] = "monospace"
from mlxtend.evaluate import confusion_matrix
from mpl_toolkits.mplot3d import Axes3D
from scipy.linalg import svd
from scipy.stats import lognorm, norm

import brc_lib.lib_df_handling as ld
import brc_lib.lib_math
import brc_lib.lib_math as lm
from brc_lib.lib_math import (
    _func_exp,
    _func_double_exp,
    _func_exp_comp,
    fit_double_exponential,
    fit_exponential_composite,
    fit_exponential,
)
import networkx as nx

# def make_new_colormap(color1, color2, logscale = True):


def nice_string_output(
        names, values, extra_spacing=0,
):
    max_values = len(max(values, key=len))
    max_names = len(max(names, key=len))
    string = ""
    for name, value in zip(names, values):
        string += "{0:s} {1:>{spacing}} \n".format(
            name,
            value,
            spacing=extra_spacing + max_values + max_names - len(name),
        )
    return string[:-2]


def _plot_confusion_matrix_mlxtend(
        conf_mat,
        hide_spines=False,
        hide_ticks=False,
        cmap=None,
        colorbar=False,
        show_absolute=True,
        show_normed=False,
        show_percent=False,
):
    """
    A modified version of mlxtend.plotting.plot_confusion_matrix
    -----------

    Plot a confusion matrix via matplotlib.
    Parameters
    -----------
    conf_mat : array-like, shape = [n_classes, n_classes]
        Confusion matrix from evaluate.confusion matrix.
    hide_spines : bool (default: False)
        Hides axis spines if True.
    hide_ticks : bool (default: False)
        Hides axis ticks if True
    cmap : matplotlib colormap (default: `None`)
        Uses matplotlib.pyplot.cm.Blues if `None`
    colorbar : bool (default: False)
        Shows a colorbar if True
    show_absolute : bool (default: True)
        Shows absolute confusion matrix coefficients if True.
        At least one of  `show_absolute` or `show_normed`
        must be True.
    show_normed : bool (default: False)
        Shows normed confusion matrix coefficients if True.
        The normed confusion matrix coefficients give the
        proportion of training examples per class that are
        assigned the correct label.
        At least one of  `show_absolute` or `show_normed`
        must be True.
    Returns
    -----------
    fig, ax : matplotlib.pyplot subplot objects
        Figure and axis elements of the subplot.
    Examples
    -----------
    For usage examples, please see
    http://rasbt.github.io/mlxtend/user_guide/plotting/plot_confusion_matrix/
    """
    if not (show_absolute or show_normed):
        raise AssertionError("Both show_absolute and show_normed are False")

    total_samples = conf_mat.sum(axis=1)[:, np.newaxis]
    normed_conf_mat = conf_mat.astype("float") / total_samples

    fig, ax = plt.subplots(figsize=(8, 8))
    ax.grid(False)
    if cmap is None:
        cmap = plt.cm.Blues

    matshow = ax.matshow(normed_conf_mat, cmap=cmap, vmin=0, vmax=1)

    if colorbar:
        cbar = plt.colorbar(matshow, fraction=0.046, pad=0.04)

    for i in range(conf_mat.shape[0]):
        for j in range(conf_mat.shape[1]):
            cell_text = ""
            if show_absolute:
                n = conf_mat[i, j]
                if n < 1000:
                    n = str(n)
                else:
                    n = matplotlib.ticker.EngFormatter(places=1).format_data(
                        conf_mat[i, j]
                    )
                cell_text += n
                if show_normed:
                    cell_text += "\n" + "("
                    cell_text += format(normed_conf_mat[i, j], ".3f") + ")"
                elif show_percent:
                    cell_text += "\n" + "("
                    cell_text += format(normed_conf_mat[i, j], ".1%") + ")"
            else:
                cell_text += format(normed_conf_mat[i, j], ".3f")
            ax.text(
                x=j,
                y=i,
                s=cell_text,
                va="center",
                ha="center",
                color="white" if normed_conf_mat[i, j] > 0.5 else "black",
            )

    if hide_spines:
        ax.spines["right"].set_visible(False)
        ax.spines["top"].set_visible(False)
        ax.spines["left"].set_visible(False)
        ax.spines["bottom"].set_visible(False)

    ax.yaxis.set_ticks_position("left")
    ax.xaxis.set_ticks_position("bottom")
    if hide_ticks:
        ax.axes.get_yaxis().set_ticks([])
        ax.axes.get_xaxis().set_ticks([])
    else:
        if len(conf_mat[0]) > 5:
            ax.axes.get_yaxis().set_ticks(range(0, len(conf_mat[0])))
            ax.axes.get_xaxis().set_ticks(range(0, len(conf_mat[0])))

    ax.set_ylim(
        sorted(ax.get_xlim(), reverse=True)
    )  # Fixes top cutoff from new matplotlib

    plt.xlabel("predicted label")
    plt.ylabel("true label")
    return fig, ax


def _plot_confmat(cm, ticks: List[str]) -> Tuple[plt.Figure, plt.Axes]:
    if not len(ticks) == len(cm[0]):
        raise ValueError("must have ticks equal to number of classes")
    cmap = matplotlib.colors.LinearSegmentedColormap.from_list(
        "", ["#929591", "white", "#e50000"]
    )
    fig_m, ax_m = _plot_confusion_matrix_mlxtend(
        cm,
        show_absolute=True,
        show_normed=False,
        show_percent=True,
        colorbar=True,
        cmap=cmap,
    )
    if len(cm[0]) <= 5:
        ticks.insert(0, " ")

    ax_m.set_yticklabels(ticks)
    ax_m.set_xticklabels(ticks, rotation=90)
    return fig_m, ax_m


def make_cumulative_plot(
        df,
        ax: plt.Axes,
        data_column="_Time",
        normalize=False,
        label_addon=None,
        exptime=20.0,
        include_diagonal=False,
        color="red",
):
    labelstr = (
        f"Cum. sum: {label_addon} by {data_column}"
        if label_addon is not None
        else f"Cum. sum by {data_column}"
    )

    arr = np.sort(df[data_column].values)
    x, cum_arr = lm.get_cumulative_event_arrs(arr)

    if normalize:
        cum_arr = cum_arr / cum_arr.max()

    ax.plot(x, cum_arr, label=labelstr, color=color)

    if exptime is not None:
        a = ax.get_xticks()

        ax.set_xticklabels(a / (1000.0 / exptime))

        ax.set_xlabel("Time (s)")
    else:
        ax.set_xlabel("Frames")

    if include_diagonal:
        ax.plot([x[0], x[-1]], [cum_arr[0], cum_arr[-1]], ls="--", lw=0.5)

    pass


# def plot_intensity_duration_hist(df, axes,):


def plot_intensity_histograms(
        df,
        axes,
        colors=None,
        n_bins=50,
        colors_plot=None,
        fit_lognorm=False,
        range_x=None,
        normalize_hist: bool = False,
        plot_gaussian: bool = False,
):
    """
    Plots liposome signals onto 3 given axes.
    :param df: Pandas DataFrame with values
    :param axes: list of 3 axes to plot the values to
    :param colors: columns (and order) to plot from DF
    :param n_bins: bins for histograme
    :param colors_plot: colors to use for plotting. will default to colors variable if nothing else
    :param fit_lognorm: bool, whether to fit a log norm to the data
    :param range_x: range to plot the hist on
    :return:
    """
    if colors == None:
        colors = [
            "red",
            "green",
            "blue",
        ]
    if colors_plot == None:
        colors_plot = dict(zip(colors, colors))

    for i, c in enumerate(colors):
        data = df[c][
            df[c] > 0
            ].values  # making sure that no negative values are passed

        if range_x is None:
            x_min = data.min()
            x_max = data.max()
        else:
            x_min = range_x[0]
            x_max = range_x[1]

        bins = np.linspace(
            data.min() if x_min is None else x_min,
            data.max() if x_max is None else x_max,
            num=n_bins + 1,
        )
        n, bins, _ = axes[i].hist(
            data,
            bins=bins,
            color=colors_plot[c],
            label="N={}".format(len(data)),
            alpha=0.5,
            density=normalize_hist,
        )

        axes[i].set_title("{}".format(c, ))

        if fit_lognorm:
            # fit a lognorm to the data, with initial guess mu 1
            lognorm_pars = lognorm.fit(data, loc=1)
            lognorm_s, lognorm_mu, lognorm_n = lognorm_pars

            lognorm_fitted = lognorm(*lognorm_pars)

            # calculate the right values
            mu_est = np.log(lognorm_n)
            mu_plot = np.exp(mu_est + np.power(lognorm_s, 2) / 2)

            sigma_plot = 0.34 * np.exp(mu_est + np.power(lognorm_s, 2) - 1 / 2)

            xarr_lnorm = np.linspace(
                data.min() if x_min is None else x_min,
                data.max() if x_max is None else x_max,
                num=200,
            )

            axes[i].plot(
                xarr_lnorm,
                lognorm_fitted.pdf(xarr_lnorm),
                color=colors_plot[c],
                label=r"$\sigma$={:.3f} $\mu$={:.3f}".format(
                    sigma_plot, mu_plot
                ),
            )

        if plot_gaussian:
            _data = data[data > range_x[0]]
            _data = _data[_data < range_x[1]]
            _mu = _data.mean()
            _sigma = _data.std() / 2
            gaussian_parametrized = norm(loc=_mu, scale=_sigma)
            xarr_plot = np.linspace(x_min, x_max, num=200)

            axes[i].plot(
                xarr_plot,
                gaussian_parametrized.pdf(xarr_plot),
                color=colors_plot[c],
                label=rf"$\sigma$={_sigma:.3f} $\mu$={_mu:.3f}",
            )

    if fit_lognorm:
        return axes, lognorm_pars, (mu_plot, sigma_plot)
    else:
        return axes


def plot_trace(df, show_bg=True):
    cols_sig, cols_raw = ld.get_signal_columns(df)
    fig, ax = plt.subplots(constrained_layout=True, figsize=(10, 3))
    for col_plot in cols_sig:
        color_plot = col_plot.split("_")[0]
        if col_plot in cols_raw:
            ax.plot(
                df[col_plot].values, c=color_plot, alpha=0.5, label=color_plot
            )
        elif show_bg == True:
            ax.plot(
                df[col_plot].values,
                c=color_plot,
                alpha=0.15,
                label="bg: {}".format(color_plot),
            )

    return fig, ax


def plot_trace_bg_corrected(df):
    cols_sig, cols_raw = ld.get_signal_columns(df)
    fig, ax = plt.subplots(constrained_layout=True, figsize=(10, 3))
    for col_plot in cols_raw:
        color_plot = col_plot.split("_")[0]
        col_bg = col_plot + "_bg"
        # normalize to 0
        xarr = df[col_plot].values - df[col_bg].values
        xarr = xarr  # - xarr.min()
        ax.plot(xarr, c=color_plot, label=color_plot, linewidth=1, alpha=0.5)

    return fig, ax


def plotROISignal(
        df_trace: pd.DataFrame,
        df_evts: pd.DataFrame,
        ROI_id: str,
        include_events: bool = True,
        corr_bg: bool = True,
):
    if corr_bg is True:
        fig, ax = plot_trace_bg_corrected(df_trace)
    else:
        fig, ax = plot_trace(df_trace)

    if (include_events is True) and (df_evts is not None):
        for evt_id, df_evt in df_evts.groupby("_event_ID"):
            evt_start = df_evt["_event_start"].values[0]
            evt_end = df_evt["_event_end"].values[0]
            ax.axvspan(
                evt_start - 0.5,
                evt_end + 0.5,
                alpha=0.3,
                label="evt:{}".format(evt_id),
                color="k",
            )

    fig.suptitle(ROI_id)
    return fig, ax


def plot_ROI_signal_sigma_trace(
        df_trace: pd.DataFrame,
        ROI_id: str,
        df_evts: Union[pd.DataFrame, None] = None,
        corr_bg: bool = False,
        n_sigma=3,
):
    if corr_bg is True:
        fig, ax = plot_trace_bg_corrected(df_trace)
    else:
        fig, ax = plot_trace(df_trace)

    param_dict = ld.get_mean_sigma_values(df_trace, corr_bg=corr_bg)

    for col in param_dict.keys():
        mean, sigma = param_dict[col]
        ax.axhline(
            mean + n_sigma * sigma,
            ls="dashed",
            color=col,
            alpha=0.5,
            label="{} Sigma / {}".format(n_sigma, col),
        )

    if df_evts is not None:
        for evt_id, df_evt in df_evts.groupby("_event_ID"):
            evt_start = df_evt["_event_start"].values[0]
            evt_end = df_evt["_event_end"].values[0]
            ax.axvspan(
                evt_start - 0.5,
                evt_end + 0.5,
                alpha=0.3,
                label="evt:{}".format(evt_id),
                color="k",
            )

    fig.suptitle(ROI_id)
    return fig, ax


def plot_SR_distance(
        df,
        ax,
        range_x=(0, 2000),
        N_bins=40,
        col="dist_nm",
        name="",
        px_size=110,
        autolabel=False,
        show_errors=False,
):
    binsize = (range_x[1] - range_x[0]) / N_bins
    width = 0.45 * binsize

    vals = df[col].values
    rects = _plot_hist(
        vals, ax, width, N_bins, range_x, name, autolabel, show_errors
    )

    if px_size is not None:
        px_ticks = [i for i in range(0, range_x[1], px_size)]
        px_labels = [f"{n} px" for n in range(len(px_ticks))]

        ax.set_xticks(px_ticks, minor=True)

        ax.set_xticklabels(px_labels, minor=True, fontsize="small", alpha=0.7)

        ax.tick_params(
            axis="x", which="minor", direction="out", length=15, rotation=45
        )

    ax.set_xticks(
        np.arange(start=range_x[0], stop=range_x[1], step=binsize)
        + 0.5
        + width / 2
    )
    ax.set_xticklabels(
        np.arange(start=range_x[0], stop=range_x[1], step=binsize)
    )

    ax.xaxis.set_tick_params(rotation=45)

    ax.legend()
    return ax


def _plot_hist(
        vals,
        ax,
        width=0.95,
        n_bins=40,
        range_x=None,
        label="",
        autolabel=False,
        show_errors=False,
        x_offset=0.0,
        normalize=True,
):
    if range_x == None:
        range_x = (0, vals.max())
    binsize = (range_x[1] - range_x[0]) / n_bins
    width = width * binsize

    x, y, sy, mask = brc_lib.lib_math.bin_data(
        vals, range_x=range_x, n_bins=n_bins, density=normalize
    )

    x += x_offset * width

    rects = ax.bar(x[mask], y[mask], width, yerr=sy[mask], label=label)

    if autolabel is True:
        autolabel_rects(rects, ax, show_errors=show_errors)

    return rects


def autolabel_rects(barContainer, ax, show_errors=False):
    """
    Attach a text label above each bar displaying its height
    """

    for rect, yerr in zip(
            barContainer, barContainer.errorbar.get_children()[0].get_segments()
    ):
        error = yerr[1, 1] - yerr[:, 1].mean()  # print error
        height = rect.get_height()
        if show_errors:
            ax.text(
                rect.get_x() + rect.get_width() / 2.0,
                1.05 * height,
                "{:.1f} +/- {:.1f}".format(height, error),
                family="monospace",
                ha="center",
                va="bottom",
            )
        else:
            ax.text(
                rect.get_x() + rect.get_width() / 2.0,
                1.05 * height,
                "{:.2f}".format(height),
                family="monospace",
                ha="center",
                va="bottom",
            )


def plot_confusion_matrix(y_true, y_pred, ticks=None):
    if ticks is None:
        ticks = ["a", "b"]
    elif not isinstance(ticks, List):
        ticks = list(ticks)
    cm = confusion_matrix(y_true, y_pred)
    fig, ax = _plot_confmat(cm, ticks=ticks)
    return fig, ax


def plot_pca(df, pca_indices=(0, 1, 2)):
    if ld.is_preprocessed(df) is False:
        X = ld.preprocess_X(df, )
    else:
        X = df

    i, j, k = pca_indices

    # PCA by computing SVD of Y
    # noinspection PyTupleAssignmentBalance
    U, S, Vh = svd(X.values, full_matrices=False)

    V = Vh.T
    Z = X @ V

    fig = plt.figure()
    ax = Axes3D(fig)  # define Axes3D to allow a 3d plot
    fig.suptitle("PCA")

    for c in pd.unique(df["_LABEL"]):
        # select indices belonging to class c:
        class_mask = (df["_LABEL"] == c).values

        ax.plot(
            Z[class_mask][i], Z[class_mask][j], Z[class_mask][k], "o", alpha=0.5
        )

    ax.legend(pd.unique(df["_LABEL"]))

    ax.set_xlabel(f"PC{i + 1}")
    ax.set_ylabel(f"PC{j + 1}")

    return fig, ax


def plot_exponential(
        _lambda: float, ax: plt.Axes, labelstr=None, _x_range=None
):
    if _x_range is None:
        _x_range = ax.get_xlim()
    _xdata = np.linspace(_x_range[0], _x_range[1] - 0.5, num=100)

    _ydata = _func_exp(_xdata, _lambda)

    ax.plot(
        _xdata + 0.5,
        _ydata,
        linewidth=0.5,
        linestyle="dashed",
        color="xkcd:forest green",
        label=rf"$\tau$ = {1 / _lambda:2f}" if labelstr is None else labelstr,
    )

    pass


def plot_exponential_composite(
        _lambda: float, _N: float, ax: plt.Axes, labelstr=None, _x_range=None
):
    if _x_range is None:
        _x_range = ax.get_xlim()
    _xdata = np.linspace(*_x_range, num=100)

    _ydata = _func_exp_comp(_xdata, _lambda, _N)

    ax.plot(
        _xdata,
        _ydata,
        linewidth=0.5,
        linestyle="dashed",
        color="xkcd:deep magenta",
        label=f"N = {_N:.2f}\nTau = {1 / _lambda:2f}"
        if labelstr is None
        else labelstr,
    )
    pass


def plot_double_exponential(
        _lambda1: float,
        _lambda2: float,
        _k: float,
        ax: plt.Axes,
        labelstr=None,
        _x_range=None,
):
    if _x_range is None:
        _x_range = ax.get_xlim()
        # ensure we dont go outside the bounds of the function
        if _x_range[0] < 0:
            _x_range = (0, _x_range[1])
    _xdata = np.linspace(*_x_range, num=100)

    _ydata = _func_double_exp(_xdata, _lambda1, _lambda2, _k)

    ax.plot(
        _xdata,
        _ydata,
        linewidth=0.5,
        linestyle="dashed",
        color="xkcd:salmon",
        label=f"Tau1 = {1. / _lambda1:.2f}\nTau2 = {1. / _lambda2:2f}\nk={_k:.2f}"
        if labelstr is None
        else labelstr,
    )
    pass


def _fit_and_plot_double_exp(axes, j, range_time, res_t, x, y):
    if np.count_nonzero(y) > 0:
        x = x[np.nonzero(y)]
        y = y[np.nonzero(y)]

    _x = x - 0.5

    _lifetime_1_unc, _lifetime_2_unc, _k_unc = fit_double_exponential(_x, y)
    if res_t == None:
        label_2exp = (
            f"tau1 = {_lifetime_1_unc:.2f}\ntau2 = {_lifetime_2_unc:.2f}"
        )
    else:
        _l1 = _lifetime_1_unc * res_t
        _l2 = _lifetime_2_unc * res_t
        label_2exp = f"tau1 = {nominal_value(_l1):.2f}\ntau2 = {nominal_value(_l2):.2f}\nk = {nominal_value(_k_unc):.2f}"
    plot_double_exponential(
        1.0 / (nominal_value(_lifetime_1_unc)),
        1.0 / (nominal_value(_lifetime_2_unc)),
        nominal_value(_k_unc),
        axes[j],
        labelstr=label_2exp,
        _x_range=range_time,
    )


def _fit_and_plot_composite_exp(axes, j, range_time, res_t, x, y):
    if np.count_nonzero(y) > 0:
        x = x[np.nonzero(y)]
        y = y[np.nonzero(y)]

    _x = x - 0.5

    _lifetime_comp_unc, _N_comp = fit_exponential_composite(_x, y)
    if res_t == None:
        label_1exp_comp = (
            rf"N   = {_N_comp:.1f}\n$\tau$ = {_lifetime_comp_unc:.2f}"
        )
    else:
        l_comp = _lifetime_comp_unc * res_t
        label_1exp_comp = rf"N   = {_N_comp:.1f}\n$\tau$ = {l_comp:.2f}"
    plot_exponential_composite(
        1.0 / (nominal_value(_lifetime_comp_unc)),
        nominal_value(_N_comp),
        axes[j],
        labelstr=label_1exp_comp,
        _x_range=range_time,
    )


def _fit_and_plot_single_exp(axes, j, range_time, res_t, x, _y):
    if np.count_nonzero(_y) > 0:
        x = x[np.nonzero(_y)]
        _y = _y[np.nonzero(_y)]

    _x = x - 0.5

    _lifetime_unc = fit_exponential(_x, _y)

    _mean_lifetime = sum(_x * _y)

    if res_t == None:
        label_1exp = rf"$\tau$ = {_lifetime_unc:.2f}"
    else:
        l = _lifetime_unc * res_t
        label_1exp = rf"$\tau$ = {l:.2f}"

    plot_exponential(
        1.0 / (nominal_value(_lifetime_unc)),
        axes[j],
        labelstr=label_1exp,
        _x_range=range_time,
    )


def plot_and_save_confusion_matrix(
        y_test,
        y_pred,
        path_confmat,
        ticks: Union[np.ndarray, None] = None,
        title_string: str = "Confusion Matrix",
):
    if ticks is None:
        ticks = np.unique(np.concatenate([y_test, y_pred]))
    fig_confmat, _ = plot_confusion_matrix(y_test, y_pred, ticks=ticks, )
    fig_confmat.suptitle(title_string)
    fig_confmat.tight_layout()
    fig_confmat.savefig(path_confmat)
    plt.close()
    pass


def plot_and_save_shap_summary(
        shap_values, X, shap_path,
):
    shap.summary_plot(shap_values, X, show=False)
    plt.legend(loc="lower right")
    plt.savefig(shap_path)
    plt.close()


def draw_graph_subnodes(G: nx.Graph) -> Tuple[plt.Figure, plt.Axes]:
    pos = nx.spring_layout(G)  # positions for all nodes
    # pos = nx.circular_layout(G)

    _labels = [G.nodes[_n]["label"] for _n in G.nodes]
    _nodes = G.nodes
    _label_dict = dict(zip(_nodes, _labels))

    # figure
    fig, ax = plt.subplots(figsize=(12, 8))

    # nodes
    nx.draw_networkx_nodes(
        G,
        pos,
        node_color=[G.nodes[_n]["color"] for _n in G.nodes],
        node_size=900,
        ax=ax,
    )

    nx.draw_networkx_edges(
        G, pos, ax=ax,
    )

    nx.draw_networkx_labels(
        G,
        pos,
        _label_dict,
        font_size=6,
        font_color="w",
        font_family="monospace",
        ax=ax,
    )

    plt.tight_layout()

    return fig, ax


def add_labels_to_nodes(G: nx.Graph, remove_colons=True, keysplit: str = "-"):
    _nodes = G.nodes
    for i, _node_id in enumerate(_nodes):
        _node = G.nodes[_node_id]

        _name_frac: str = _node["name"].rsplit(keysplit, maxsplit=1)[-1]
        if remove_colons:
            _name_frac = _name_frac.replace(":", "")

        if _name_frac[0].isdigit():
            _name_frac = "--" + _name_frac

        _node_label = f'{_name_frac}\n{_node["score"]:.3f}'

        G.nodes[_node_id]["label"] = _node_label


def add_edge_weights(G: nx.Graph):
    _new_edges = []
    for _edge in G.edges:
        _n1, _n2 = _edge

        _w = np.abs(G.nodes[_n1]["score"] - G.nodes[_n2]["score"])

        _new_edge = (_n1, _n2, _w)

        _new_edges.append(_new_edge)

    G.add_weighted_edges_from(_new_edges)


def plot_tree_from_file(
        input_path: Path, save: bool = True, save_path: Union[Path, None] = None
):
    if save_path is None:
        save_path = input_path.with_suffix(".pdf")
    G: nx.Graph = pickle.load(open(str(input_path), "rb"))
    add_labels_to_nodes(G, keysplit="-")
    fig, ax = draw_graph_subnodes(G)
    if save:
        fig.savefig(save_path)
    else:
        return fig, ax


if __name__ == "__main__":
    y_pred = np.random.randint(0, 2, 2000)
    y_true = np.random.randint(0, 2, 2000)

    plot_confusion_matrix(y_pred, y_true)

    plt.show()
