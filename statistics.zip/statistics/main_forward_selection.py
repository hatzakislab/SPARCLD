from pathlib import Path

from brc_lib.lib_plotting import plot_tree_from_file

TEST = False
data_dir = Path(
    "/Users/mag/Documents/study/phd/barcodeAssay/data/barcode_library/library_4/"
)
out_dir = Path(
    "/Users/mag/Documents/study/phd/barcodeAssay/results/models/new_library/"
)
out_dir.mkdir(exist_ok=True)
out_path = out_dir.joinpath("new_library_FS.pkl")
fig_path = out_path.with_suffix(".pdf")

# train_files = [i for i in data_dir.glob('*.csv')]
# forward_selection(train_files, out_path=out_path, label_type='new', model_type='xgboost_multi', TEST=TEST)

f, a = plot_tree_from_file(out_path, save=False)
a.set_title("Forward Selection")
f.tight_layout()
f.savefig(fig_path)
