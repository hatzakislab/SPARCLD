import sys
from pathlib import Path

import pandas as pd
from PyQt5.QtWidgets import QApplication, QFileDialog

color_cols = [
    "red",
    "green",
    "blue",
]

raw_cols = [
    "red",
    "green",
    "blue",
    "red_bg",
    "green_bg",
    "blue_bg",
]


def get_filename(
        return_path: bool = False,
        initial_filter="All Files (*)",
        title="Select File",
        initial_dir: Path = Path.cwd(),
):
    """
    Returns a path object for a file name
    :param return_path: bool, whether to return parent directory of selected file
    :param initial_filter: str, file filter (passed to QFileDialog)
    :param title: window title
    :param initial_dir: Pathlib object, defines start directory to search from. Defaults to Path.cwd()
    :return p: Path object, with either directory or path to file
    """
    q = QApplication(sys.argv)
    # noinspection PyArgumentList
    f = QFileDialog(caption=title)
    fname, filter = f.getOpenFileName(
        directory=str(initial_dir), initialFilter=initial_filter
    )

    p = Path(fname)

    f.close()

    return p if return_path is False else p.parent


def get_filename_save(title="Save File", initial_dir=Path.cwd()):
    """
    :param title: window title
    :param initial_dir: Pathlib object, defines start directory to search from. Defaults to Path.cwd()
    :return p: Path object
    """
    q = QApplication(sys.argv)
    f = QFileDialog(caption=str(title))
    fname, filter = f.getSaveFileName(directory=str(initial_dir), )

    p = Path(fname)

    f.close()

    return p


# CSV handling functions here


if __name__ == "__main__":
    from brc_lib.lib_df_handling import read_old_csv, correct_bg

    pd.set_option("display.max_columns", 500)
    p = Path(
        "/Users/mag/Documents/study/phd/barcodeAssay/data/20190325/csvs/A/10ms"
    )
    fp = p.glob("*.csv")

    for f in fp:
        df = read_old_csv(f)
        print(df.head())
        df = correct_bg(df)
        print(df.head())
        exit()
